package com.capgemini.storemanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoremangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
