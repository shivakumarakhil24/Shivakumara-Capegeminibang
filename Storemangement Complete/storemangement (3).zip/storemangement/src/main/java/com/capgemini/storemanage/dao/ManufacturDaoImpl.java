package com.capgemini.storemanage.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.exceptions.StoreManagementSystemException;

@Repository
public class ManufacturDaoImpl implements ManufacturDao {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	Users admin = new Users();

	// To login manufacture
	@Override
	public Users loginManufact(String userId, String password) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Users where userId=:login_id and password=:password";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("login_id", userId);
		query.setParameter("password", password);
		Users users = null;
		try {
			users = (Users) query.getSingleResult();
			if (users == null) {
				System.out.println("Manufacturer is not exist....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
		return users;
	}

	// To add Dealer
	@Override
	public boolean addDealer(Users dealer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		boolean isadded = false;
		try {

			dealer.setRole("dealer");
			transaction.begin();
			entityManager.persist(dealer);
			transaction.commit();
			isadded = true;

		} catch (Exception e) {
			throw new StoreManagementSystemException("Dealer already exist");
		}
		entityManager.close();
		return isadded;
	}

	// To edit dealer
	@Override
	public boolean modifyDealer(Users dealer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		Users dealerNew = entityManager.find(Users.class, dealer.getUserId());
		boolean isUpdate = false;

		if (dealer != null) {
			dealerNew.setRole("dealer");
			
			String daelerId=dealer.getUserId();
			if(daelerId != null) {
				dealerNew.setUserId(daelerId);
			}

			String dealerName = dealer.getUserName();
			if (dealerName != null) {
				dealerNew.setUserName(dealerName);
			}
			String password = dealer.getPassword();
			if (password != null) {
				dealerNew.setPassword(password);
			}

			String location = dealer.getLocation();
			if (location != null) {
				dealerNew.setLocation(location);

			}
			String email = dealer.getEmail();
			if (email != null) {
				dealerNew.setEmail(email);
			}
			try {
				transaction.commit();
				isUpdate = true;

			} catch (Exception e) {
				e.printStackTrace();
			}
			entityManager.close();

		}
		return isUpdate;
	}

	// To Delete dealer
	@Override
	public boolean removeDealer(String dealerId) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			Users dealer = null;
			dealer = entityManager.find(Users.class, dealerId);

			transaction.begin();
			entityManager.remove(dealer);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			throw new StoreManagementSystemException("Failed to delete Dealer");
		}
		entityManager.close();
		return true;
	}

	// To View all Dealers
	@Override
	public List<Users> viewAllDealers() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<Users> dealers = null;
		String jpql = "from Users where role=:deal";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("deal", "Dealer");
		dealers = query.getResultList();
		entityManager.close();
		return dealers;
	}

	// To add product
	@Override
	public boolean addProduct(Products product) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		boolean isadded = false;
		try {
			transaction.begin();
			entityManager.persist(product);
			transaction.commit();
			isadded = true;

		} catch (Exception e) {
			throw new StoreManagementSystemException("Prodcut already exist");
		}
		entityManager.close();
		return isadded;
	}

	// To Edit product
	
	  @Override public boolean modifyProduct(Products product) { 
		  EntityManager entityManager = entityManagerFactory.createEntityManager();
			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			Products productNew = entityManager.find(Products.class, product.getProductId());
			boolean isUpdate = false;

			if (productNew != null) {
				
				Integer productId=product.getProductId();
				if(productId != null) {
					productNew.setProductId(productId);
				}

				String brand = product.getBrand();
				if (brand != null) {
					productNew.setBrand(brand);
				}
				Double price = product.getPrice();
				if (price != null) {
					productNew.setPrice(price);
				}

				Integer stocks = product.getStocks();
				if (stocks != null) {
					productNew.setStocks(stocks);

				}
				String image = product.getImageUrl();
				if (image != null) {
					productNew.setImageUrl(image);
				}
				
				String warranty =product.getWarranty();
				if (warranty != null) {
					productNew.setWarranty(warranty);
				}
					
				try {
					transaction.commit();
					isUpdate = true;

				} catch (Exception e) {
					e.printStackTrace();
				}
				entityManager.close();

			}
			return isUpdate;
		  
	  }
	 

	
	//To remove Product
	@Override
	public boolean removeProduct(Integer productId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			Products product = null;
			product = entityManager.find(Products.class, productId);

			transaction.begin();
			entityManager.remove(product);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			throw new StoreManagementSystemException("Failed to delete Product");
		}
		entityManager.close();
		return true;
	}

	
	// View all products
	@Override
	public List<Products> viewAllProducts() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Products";
		Query query = entityManager.createQuery(jpql);
		List<Products> productsList = null;
		try {
			productsList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return productsList;
	}
	
	
// View all orders
	@Override
	public List<Orders> viewAllOrders() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Orders";
		Query query = entityManager.createQuery(jpql);
		List<Orders> ordersList = null;
		try {
			ordersList = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ordersList;
	}

	
// To view all stores
	@Override
	public List<StoreUnit> viewStore() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from StoreUnit";
		Query query = entityManager.createQuery(jpql);
		List<StoreUnit> stores = null;
		try {
			stores = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return stores;
	}

	
}
