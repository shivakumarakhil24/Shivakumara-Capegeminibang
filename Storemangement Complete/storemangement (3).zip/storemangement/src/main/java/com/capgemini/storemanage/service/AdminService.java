package com.capgemini.storemanage.service;

import java.util.List;

import com.capgemini.storemanage.beans.Users;

public interface AdminService {
	public Users loginAdmin(String userId, String password);
	
	public boolean addManufactur(Users user);
	public boolean updateManufactur(Users user);
	public boolean deleteManufactur(String userId);
	public List<Users> viewAllManufacturs();


}
