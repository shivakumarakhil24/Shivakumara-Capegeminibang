package com.capgemini.storemanage.dao;

import java.util.List;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;

public interface ManufacturDao {
	public Users loginManufact(String userId, String password);
	
	public boolean addDealer(Users dealer);
	public boolean modifyDealer(Users dealer);
	public boolean removeDealer(String dealerId);
	public List<Users> viewAllDealers();
	
	public boolean addProduct(Products product);
	public boolean modifyProduct(Products product);
	public boolean removeProduct(Integer productId);
	public List<Products> viewAllProducts();
	
	public List<Orders> viewAllOrders();
	public List<StoreUnit> viewStore(); 
	

	
	
	
	
	


}
