package com.capgemini.storemanage.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_details")
public class Products {
	@Id
	@Column
	private Integer productId;
	@Column
	private String brand;
	@Column
	private Double price;
	@Column
	private String warranty;
	@Column
	private Integer stocks;
	@Column
	private String imageUrl;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}

	public Integer getStocks() {
		return stocks;
	}

	public void setStocks(Integer stocks) {
		this.stocks = stocks;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Products [productId=" + productId + ", brand=" + brand + ", price=" + price + ", warranty=" + warranty
				+ ", stocks=" + stocks + ", imageUrl=" + imageUrl + "]";
	}

}
