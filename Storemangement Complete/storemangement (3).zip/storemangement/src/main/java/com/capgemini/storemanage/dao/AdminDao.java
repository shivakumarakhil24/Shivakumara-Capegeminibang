package com.capgemini.storemanage.dao;

import java.util.List;

import com.capgemini.storemanage.beans.Users;

public interface AdminDao {

	public Users loginAdmin(String userId, String password);

	public boolean addManufactur(Users user);
	public boolean updateManufactur(Users userId);
	public boolean deleteManufactur(String userId);
	public List<Users> viewAllManufacturs();

}
