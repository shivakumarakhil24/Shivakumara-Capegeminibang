package com.capgemini.storemanage.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.hibernate.tool.schema.spi.SchemaManagementException;
import org.springframework.stereotype.Repository;

import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.exceptions.StoreManagementSystemException;

@Repository
public class AdminDaoImpl implements AdminDao {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Override
	public Users loginAdmin(String userId, String password) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Users where userId=:login_id and password=:password";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("login_id", userId);
		query.setParameter("password", password);
		Users users = null;
		try {
			users = (Users) query.getSingleResult();
			if (users == null) {
				System.out.println("Dealer is not exist....");
			}
		} catch (Exception e) {
			throw new SchemaManagementException("Login failed");
		}
		entityManager.close();
		return users;
	}// End of loginAdmin

	@Override
	public boolean addManufactur(Users user) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		boolean isadded = false;
		try {

			user.setRole("manufacture");
			transaction.begin();
			entityManager.persist(user);
			transaction.commit();
			isadded = true;

		} catch (Exception e) {
			throw new StoreManagementSystemException("Id already exist");
		}
		entityManager.close();
		return isadded;
	}// End of AddManufacturer


	//Update manufacturer
	@Override
	public boolean updateManufactur(Users user) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		Users manufactur = entityManager.find(Users.class, user.getUserId());
		boolean isUpdate = false;

		if (manufactur != null) {
			manufactur.setRole("Manufacture");
			
			String manufactureId=user.getUserId();
			if(manufactureId != null) {
				manufactur.setUserId(manufactureId);
			}

			String manufacturName = user.getUserName();
			if (manufacturName != null) {
				manufactur.setUserName(manufacturName);
			}
			String password = user.getPassword();
			if (password != null) {
				manufactur.setPassword(password);
			}

			String location = user.getLocation();
			if (location != null) {
				manufactur.setLocation(location);

			}
			String email = user.getEmail();
			if (email != null) {
				manufactur.setEmail(email);
			}
			try {
				transaction.commit();
				isUpdate = true;

			} catch (Exception e) {
				e.printStackTrace();
			}
			entityManager.close();

		}
		return isUpdate;
	}// end of update User

	@Override
	public boolean deleteManufactur(String userId) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			Users manufact = null;
			manufact = entityManager.find(Users.class, userId);

			transaction.begin();
			entityManager.remove(manufact);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			throw new StoreManagementSystemException("Failed to delete Manufacture");
		}
		entityManager.close();
		return true;
	}

	// To see all manufacture
	@Override
	public List<Users> viewAllManufacturs() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<Users> manufactures = null;
		String jpql = "from Users where role=:man";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("man", "Manufacture");
		manufactures = query.getResultList();
		entityManager.close();
		return manufactures;
	}
}
