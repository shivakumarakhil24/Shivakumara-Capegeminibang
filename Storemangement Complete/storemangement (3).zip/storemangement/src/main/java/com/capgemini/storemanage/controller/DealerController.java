package com.capgemini.storemanage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.exceptions.StoreManagementSystemException;
import com.capgemini.storemanage.service.DealerService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DealerController {
	@Autowired
	private DealerService dealerService;

	@PostMapping(path = "/dealerLogin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Users loginDealerService(@RequestBody Users dealer) {
		Users users = new Users();
		try {
			users = dealerService.loginDealer(dealer.getUserId(), dealer.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}// End of dealer login
	
	@GetMapping(path = "/showAllProducts", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<Products> showAllProducts() {
		List<Products> allProduct = dealerService.showAllproducts();
		if (allProduct != null) {
			for (Products products : allProduct) {
				System.out.println(products);
			}
			return allProduct;
		} else {
			return null;
		}
	}// End of showAllProducts
	
	@GetMapping(path = "/viewMyStore/{storeId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<StoreUnit> viewMyStore(@PathVariable("storeId")Integer storeId) {
		List<StoreUnit> store = dealerService.viewMyStore(storeId);
		if (store != null) {
			for (StoreUnit storedata : store) {
				System.out.println(storedata);
			}
			return store;
		} else {
			return null;
		}
	
	}// End ViewMyStore
	
	@PutMapping(path = "/placeOrder", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean placeOrder(@RequestBody Orders order) {
		try {
			if (dealerService.makeOrder(order)) {
				return true;
			} else {
				return false;
			}
		} catch (StoreManagementSystemException e) {
			e.printStackTrace();
		}
		return false;
	}// End of Place Order
	
	@DeleteMapping(path = "/cancelOrder/{orderId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public boolean cancelOrder(@PathVariable("orderId") Integer orderId) {
		boolean isDeleted = dealerService.deleteOrder(orderId);
		if(isDeleted) {
			return true;
		}
		return false;
	}// end of cancel order
	
	@GetMapping(path = "/myOrders/{userId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<Orders> myOrders(@PathVariable("userId")String userId) {
		List<Orders> myorder = dealerService.viewMyOrders(userId);
		if (myorder != null) {
			for (Orders order : myorder) {
				System.out.println(order);
			}
			return myorder;
		} else {
			return null;
		}
	
	}// End ViewMyorders


}
