package com.capgemini.storemanage.controller;

import java.util.List;

import org.hibernate.tool.schema.spi.SchemaManagementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.exceptions.StoreManagementSystemException;
import com.capgemini.storemanage.service.AdminService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {
	@Autowired
	private AdminService adminService;

	@PostMapping(path = "/adminLogin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Users loginAdminService(@RequestBody Users u) {
		Users users = new Users();
		try {
			users = adminService.loginAdmin(u.getUserId(), u.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}// End of Adminlogin

	@PutMapping(path = "/addmanufacture", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean addManufacture(@RequestBody Users manufacture) {
		try {
			if (adminService.addManufactur(manufacture)) {
				return true;
			} else {
				return false;
			}
		} catch (SchemaManagementException e) {
			e.printStackTrace();
		}
		return false;
	}// End of AddManufacture

	
	
	@PostMapping(path = "/updateManufacture", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean updatemanufacture(@RequestBody Users manufactutre) {
		return adminService.updateManufactur(manufactutre);
	}// End of Update Manufacture

	
	
	@DeleteMapping(path = "/deleteManufacture/{userId}")
	public boolean deletemanufacture(@PathVariable("userId") String userId) {
		boolean isDeleted = adminService.deleteManufactur(userId);
		if(isDeleted) {
			return true;
		}
		return false;
	}// end of delete Manufacture
	
	
	@GetMapping(path = "/getAllManufacture",produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<Users> getAllmanufactures() {
		List<Users> allManufactures = adminService.viewAllManufacturs();
		if(allManufactures != null) {
			return allManufactures;
		} else {
			return null;
		}
		
	}// GetAllManufacture

}
