package com.capgemini.storemanage.exceptions;

public class StoreManagementSystemException extends RuntimeException {
	public StoreManagementSystemException(String message) {
		super(message);
	}

}
