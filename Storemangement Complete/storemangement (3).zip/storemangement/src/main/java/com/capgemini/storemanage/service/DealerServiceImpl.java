package com.capgemini.storemanage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.dao.DealerDao;

@Service
public class DealerServiceImpl implements DealerService {
	
	@Autowired(required = true)
	private DealerDao dao; 

		
		@Override
		public Users loginDealer(String userId, String password) {
			return dao.loginDealer(userId, password);
		}


		@Override
		public boolean makeOrder(Orders order) {
			return dao.makeOrder(order);
		}


		@Override
		public boolean deleteOrder(Integer orderId) {
			return dao.deleteOrder(orderId);
		}


		@Override
		public List<Products> showAllproducts() {
			return dao.showAllproducts();
		}


		@Override
		public List<StoreUnit> viewMyStore(Integer storeId) {
			return dao.viewMyStore(storeId);
		}


		@Override
		public List<Orders> viewMyOrders(String userId) {
			return dao.viewMyOrders(userId);
		}
	
	

}
