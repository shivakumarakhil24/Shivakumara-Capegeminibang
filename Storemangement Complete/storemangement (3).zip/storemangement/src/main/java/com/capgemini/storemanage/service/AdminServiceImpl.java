package com.capgemini.storemanage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.dao.AdminDao;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired(required = true)
	private AdminDao dao;

	@Override
	public Users loginAdmin(String userId, String password) {
		return dao.loginAdmin(userId, password);
	}

	@Override
	public boolean addManufactur(Users user) {
		return dao.addManufactur(user);
	}

	@Override
	public boolean updateManufactur(Users user) {
		return dao.updateManufactur(user);
	}

	@Override
	public boolean deleteManufactur(String userId) {
		return dao.deleteManufactur(userId);
	}

	@Override
	public List<Users> viewAllManufacturs() {
		return dao.viewAllManufacturs();
	}

}
