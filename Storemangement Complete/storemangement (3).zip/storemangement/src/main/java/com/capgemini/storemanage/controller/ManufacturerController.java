package com.capgemini.storemanage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.exceptions.StoreManagementSystemException;
import com.capgemini.storemanage.service.ManufacturService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ManufacturerController {
	@Autowired
	private ManufacturService manService;

	@PostMapping(path = "/manufacturLogin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Users loginManufacturService(@RequestBody Users manufactur) {
		Users users = new Users();
		try {
			users = manService.loginManufact(manufactur.getUserId(), manufactur.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}// End of ManufactureloginService

	@GetMapping(path = "/getAllDealers", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<Users> getAllmanufactures() {
		List<Users> allDealers = manService.viewAllDealers();
		if (allDealers != null) {
			return allDealers;
		} else {
			return null;
		}
	}// End of getAllDealers

	@PutMapping(path = "/addDealer", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean addDealer(@RequestBody Users dealer) {
		try {
			if (manService.addDealer(dealer)) {
				return true;
			} else {
				return false;
			}
		} catch (StoreManagementSystemException e) {
			e.printStackTrace();
		}
		return false;
	}// End of AddDealer
	

	@PostMapping(path = "/updateDealer", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean updateDealer(@RequestBody Users dealer) {
		return manService.modifyDealer(dealer);
	}// End of Update Dealer
	
	
	@DeleteMapping(path = "/deleteDealer/{userId}")
	public boolean deletemanufacture(@PathVariable("userId") String dealerId) {
		boolean isDeleted = manService.removeDealer(dealerId);
		if(isDeleted) {
			return true;
		}
		return false;
	}// end of delete Manufacture
	
	@PutMapping(path = "/addProducts", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean addProduct(@RequestBody Products product) {
		try {
			if (manService.addProduct(product)) {
				return true;
			} else {
				return false;
			}
		} catch (StoreManagementSystemException e) {
			e.printStackTrace();
		}
		return false;
	}// End of AddProduct

	
	@DeleteMapping(path = "/deleteProduct/{productId}")
	public boolean deleteProduct(@PathVariable("productId") Integer proId) {
		boolean isDeleted = manService.removeProduct(proId);
		if(isDeleted) {
			return true;
		}
		return false;
	}// end of delete Products
	
	@GetMapping(path = "/getAllProducts", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<Products> getAllProducts() {
		List<Products> allProduct = manService.viewAllProducts();
		if (allProduct != null) {
			for (Products products : allProduct) {
				System.out.println(products);
			}
			return allProduct;
		} else {
			return null;
		}
	}// End of getAllDealers
	
	@GetMapping(path = "/getAllOrders",produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<Orders> getAllOrders() {
		List<Orders> allOrders = manService.viewAllOrders();
		if(allOrders != null) {
			return allOrders;
		} else {
			return null;
		}
		
	}// GetAllManufacture
	
	@GetMapping(path = "/viewStore",produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public List<StoreUnit> viewStore(){
		List<StoreUnit> store = manService.viewStore();
		if(store != null) {
			return store;
		} else {
			return null;
		} 
	}
	
	@PostMapping(path = "/updateProducts", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean updateProducts(@RequestBody Products product) {
		return manService.modifyProduct(product);
	}// End of Update Dealer


}
