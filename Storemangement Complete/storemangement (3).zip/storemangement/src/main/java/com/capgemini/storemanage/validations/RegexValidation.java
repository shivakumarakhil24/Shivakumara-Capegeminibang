package com.capgemini.storemanage.validations;

public class RegexValidation {

}
