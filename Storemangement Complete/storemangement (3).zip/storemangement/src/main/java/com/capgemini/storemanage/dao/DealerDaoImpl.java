package com.capgemini.storemanage.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.hibernate.tool.schema.spi.SchemaManagementException;
import org.springframework.stereotype.Repository;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.exceptions.StoreManagementSystemException;

@Repository
public class DealerDaoImpl implements DealerDao {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	Users admin = new Users();

	//To Login dealer
	@Override
	public Users loginDealer(String userId, String password) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Users where userId=:login_id and password=:password";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("login_id", userId);
		query.setParameter("password", password);
		Users users = null;
		try {
			users = (Users) query.getSingleResult();
			if (users == null) {
				System.out.println("User is not exist....");
			}
		} catch (Exception e) {
		throw new StoreManagementSystemException("Unable to Login your accout check Your UserId and Password");
		}
		entityManager.close();
		return users;

	}

	
	//To Place order
	@Override
	public boolean makeOrder(Orders order) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		boolean isOrder = false;
		try {
			transaction.begin();
			entityManager.persist(order);
			transaction.commit();
			isOrder = true;

		} catch (Exception e) {
			throw new StoreManagementSystemException("Unable to place order");
		}
		entityManager.close();
		return isOrder;
	}

	
	//To see all products of manufacture
	@Override
	public List<Products> showAllproducts() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Products";

		Query query = entityManager.createQuery(jpql);

		List<Products> productList = null;
		try {
			productList = query.getResultList();
		} catch (Exception e) {
			throw new StoreManagementSystemException("No products are Available");
		}
		entityManager.close();
		return productList;
	}

	
	//To view my store
	@Override
	public List<StoreUnit> viewMyStore(Integer storeId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String selectQry = "from StoreUnit where storeId=:dealerStore";

		Query query = entityManager.createQuery(selectQry);
		query.setParameter("dealerStore", storeId);

		List<StoreUnit> storeList = null;
		try {
			storeList = query.getResultList();
		} catch (Exception e) {
			throw new StoreManagementSystemException("No products avilable in your store ");
		}
		entityManager.close();
		return storeList;
	}

	
	//To delete Order
	@Override
	public boolean deleteOrder(Integer orderId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			Orders order = null;
			order = entityManager.find(Orders.class, orderId);
			transaction.begin();
			entityManager.remove(order);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			throw new StoreManagementSystemException("Failed to delete your order");
		}
		entityManager.close();
		return true;
	}


	@Override
	public List<Orders> viewMyOrders(String userId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Orders where userId=:myId";

		Query query = entityManager.createQuery(jpql);
		query.setParameter("myId", userId);

		List<Orders> myOrders = null;
		try {
			myOrders = query.getResultList();
		} catch (Exception e) {
			throw new StoreManagementSystemException("No orders avilable in your cart ");
		}
		entityManager.close();
		return myOrders;	}

}
