package com.capgemini.storemanage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.storemanage.beans.Orders;
import com.capgemini.storemanage.beans.Products;
import com.capgemini.storemanage.beans.StoreUnit;
import com.capgemini.storemanage.beans.Users;
import com.capgemini.storemanage.dao.ManufacturDao;

@Repository
public class ManufacturServiceImpl implements ManufacturService {

	@Autowired(required = true)
	private ManufacturDao dao;

	@Override
	public Users loginManufact(String userId, String password) {
	return dao.loginManufact(userId, password);
	}

	@Override
	public boolean addDealer(Users dealer) {
		return dao.addDealer(dealer);
	}

	@Override
	public boolean modifyDealer(Users dealer) {
		return dao.modifyDealer(dealer);
	}

	@Override
	public boolean removeDealer(String dealerId) {
		return dao.removeDealer(dealerId);
	}

	@Override
	public List<Users> viewAllDealers() {
		return dao.viewAllDealers();
	}

	@Override
	public boolean addProduct(Products product) {
		return dao.addProduct(product);
	}

	@Override
	public boolean modifyProduct(Products product) {
		return dao.modifyProduct(product);
	}

	@Override
	public boolean removeProduct(Integer productId) {
		return dao.removeProduct(productId);
	}

	@Override
	public List<Products> viewAllProducts() {
		return dao.viewAllProducts();
	}

	@Override
	public List<Orders> viewAllOrders() {
		return dao.viewAllOrders();
	}

	@Override
	public List<StoreUnit> viewStore() {
		return dao.viewStore();
	}
	
	
	
}
