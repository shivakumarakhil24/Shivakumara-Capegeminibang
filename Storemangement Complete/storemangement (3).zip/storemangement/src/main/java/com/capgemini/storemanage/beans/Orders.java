package com.capgemini.storemanage.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "order_details")
public class Orders {
	@Id
	@Column
	private Integer referenceId;
	@Column
	private Integer orderId;
	@Column
	private Integer productId;
	@Column
	private Integer quantity;
	@Column
	private String location;
	@Column
	private String userId;
	
	

	public Integer getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(Integer resferenceId) {
		this.referenceId = resferenceId;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Orders [resferenceId=" + referenceId + ", orderId=" + orderId + ", productId=" + productId
				+ ", quantity=" + quantity + ", location=" + location + ", userId=" + userId + "]";
	}
}
