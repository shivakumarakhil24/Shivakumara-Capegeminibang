package com.capgemini.storemanage.beans;

public class StoreMangementResponse {
	private int statusCde;
	private String status;
	private String description;
	public int getStatusCde() {
		return statusCde;
	}
	public void setStatusCde(int statusCde) {
		this.statusCde = statusCde;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
