import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showall-products',
  templateUrl: './showall-products.component.html',
  styleUrls: ['./showall-products.component.css']
})
export class ShowallProductsComponent implements OnInit {

  products: Product[] = [
    {

      productId: 123,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://image.shutterstock.com/image-photo/group-four-young-diverse-girls-260nw-605616242.jpg'
    },
     {
      productId: 126,
      productBrand: 'dfghhf',
      productPrice: 1500,
      productWarranty: '2 year',
      imageURL: 'https://media-public.canva.com/MADatrkRmAI/1/thumbnail_large-1.jpg'
    },
    {
      productId: 127,
      productBrand: 'wertyuiuyt',
      productPrice: 2300,
      productWarranty: '6 year',
      imageURL: 'https://image.shutterstock.com/image-photo/businessman-classic-vest-against-row-260nw-119686276.jpg'
    },
    {
      productId: 129,
      productBrand: 'ertuyt',
      productPrice: 4300,
      productWarranty: '6 year',
      imageURL: 'https://image.shutterstock.com/image-photo/designer-kurta-salwar-kamiz-on-260nw-1383140402.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://media-public.canva.com/MADar94c1zI/1/thumbnail_large-1.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://cdn.pixabay.com/photo/2012/07/29/21/42/dresses-53319__340.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://media-public.canva.com/MADer9peg3c/1/thumbnail_large.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://image.shutterstock.com/image-photo/beautiful-young-woman-posing-sunglasses-260nw-242494966.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://cdn.pixabay.com/photo/2016/12/06/09/31/blank-1886008__340.png'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://cdn.pixabay.com/photo/2016/08/12/00/36/legendary-1587325__340.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://image.shutterstock.com/image-photo/pakistani-indian-brides-lengha-skirt-260nw-1395564806.jpg'
    },
    {
      productId: 125,
      productBrand: 'Wrangler',
      productPrice: 1300,
      productWarranty: '1 year',
      imageURL: 'https://cdn.pixabay.com/photo/2015/04/22/15/08/saree-734918__340.jpg'
    }

  ];

  constructor(private router: Router) { }

  ngOnInit() {
  }

  redirect() {
    this.router.navigateByUrl('/productform')
  }
}
