import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-dealer',
  templateUrl: './delete-dealer.component.html',
  styleUrls: ['./delete-dealer.component.css']
})
export class DeleteDealerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
