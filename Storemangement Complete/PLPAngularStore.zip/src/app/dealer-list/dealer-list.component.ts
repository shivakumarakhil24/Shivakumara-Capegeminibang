import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealer-list',
  templateUrl: './dealer-list.component.html',
  styleUrls: ['./dealer-list.component.css']
})
export class DealerListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
