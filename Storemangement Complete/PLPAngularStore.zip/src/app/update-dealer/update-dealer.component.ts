import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-dealer',
  templateUrl: './update-dealer.component.html',
  styleUrls: ['./update-dealer.component.css']
})
export class UpdateDealerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
