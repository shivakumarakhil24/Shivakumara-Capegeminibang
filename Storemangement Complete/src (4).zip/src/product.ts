export class Product {
    constructor(
        public productId: number,
        public productBrand: string,
        public productPrice: number,
        public productWarranty: string,
        public imageURL: string

        ) { }
}
