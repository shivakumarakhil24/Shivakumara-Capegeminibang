import { Component, OnInit } from '@angular/core';
import { DealerService } from '../dealer.service';
import { ManufacturerService } from '../manufacturer.service';

@Component({
  selector: 'app-view-my-order',
  templateUrl: './view-my-order.component.html',
  styleUrls: ['./view-my-order.component.css']
})
export class ViewMyOrderComponent implements OnInit {
  Orders = {
    orderId: null,
    productId: null,
    userId: null,
    quantity: null,
    location: null,
  };

  orders: any[];
  constructor(private service: ManufacturerService) {
    this.viewAllOrders();
  }

  viewAllOrders() {
    this.service.viewAllOrders().subscribe(order => {
      console.log(order);
      this.orders = order;
    }, err => {
      console.log(err);
    }, () => {
      console.log('completed successfully');
    });
  }
ngOnInit() {
}
}
