import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  canActivate(
    route: ActivatedRouteSnapshot): boolean {
    let expectedRoleArray = route.data.expectedRole;
    let userDetails = JSON.parse(localStorage.getItem('admin'));
    for (let index in expectedRoleArray) {
      if (userDetails && userDetails.role === expectedRoleArray[index]) {
        return true;
      } else {
        return false;
      }
    }
  }

  

}
