import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service: AdminService, private router: Router) { }

  login(loginForm) {
    console.log(loginForm.value);
    const userId = loginForm.value.userid;
    const password = loginForm.value.password;
    this.service.loginAdmin({userId, password}).subscribe(data => {
      console.log(data);
      if (data != null) {
      if (data.role === 'admin') {
        this.router.navigateByUrl('/admin');
      } else if (data.role === 'dealer') {
        this.router.navigateByUrl('/dealer');
      } else if (data.role === 'manufacture') {
        this.router.navigateByUrl('/manufacturer');
      } else {
        this.router.navigateByUrl('/login');
      }

      localStorage.setItem('user', JSON.stringify(data));
    } 
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
