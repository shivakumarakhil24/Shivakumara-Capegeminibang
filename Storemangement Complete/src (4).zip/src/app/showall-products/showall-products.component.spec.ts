import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowallProductsComponent } from './showall-products.component';

describe('ShowallProductsComponent', () => {
  let component: ShowallProductsComponent;
  let fixture: ComponentFixture<ShowallProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowallProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowallProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
