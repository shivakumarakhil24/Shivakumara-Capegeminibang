import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-manufacturer',
  templateUrl: './add-manufacturer.component.html',
  styleUrls: ['./add-manufacturer.component.css']
})
export class AddManufacturerComponent implements OnInit {

  constructor(private service: AdminService , private router : Router) { }
  AddManufacture(form: NgForm) {
    console.log(form.value);
    this.service.addManufacturer(form.value).subscribe(data => {
      console.log(data);
      this.router.navigateByUrl('manufactureList');

    }, err => {
      console.log(err);
    }, () => {
      console.log('Dealer Added Successfully');
    });
  }






  ngOnInit() {
  }

}
