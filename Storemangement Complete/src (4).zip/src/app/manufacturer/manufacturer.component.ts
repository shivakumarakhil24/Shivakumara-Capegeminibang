import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manufacturer',
  templateUrl: './manufacturer.component.html',
  styleUrls: ['./manufacturer.component.css']
})
export class ManufacturerComponent implements OnInit {

  Allproducts = {
    _id: null,
    productId: null,
    brand: null,
    price: null,
    warranty: null,
    stocks: null,
    imageUrl: null
  };

  products: any[];
  constructor(private service: ManufacturerService) {
    this.getAllProducts();
  }

  getAllProducts() {
    this.service.getAllProducts().subscribe(data => {
      console.log(data);
      this.products = data;
    }, err => {
      console.log(err);
    }, () => {
      console.log('products got successfully');
    });
  }



  updateData(product) {
    this.Allproducts = product;
  }
  UpdateProduct(form: NgForm) {
    this.service.updateProduct(form.value).subscribe(product => {
      this.service.getAllProducts();
    }, err => {
      console.log(err);
    }, () => {
      console.log('Updated successfully');
    });
  }

  deleteProduct(productId) {
    this.service.deleteProduct(productId).subscribe(data => {
      console.log(data);
      this.getAllProducts();
    }, err => {
      console.log(err);
    }, () => {
      console.log('deleted suuccesfully');
    });
  }
  ngOnInit() {
  }

}
