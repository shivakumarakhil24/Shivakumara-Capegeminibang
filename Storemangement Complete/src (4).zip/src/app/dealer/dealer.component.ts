import { Component, OnInit } from '@angular/core';
import { DealerService } from '../dealer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-dealer',
  templateUrl: './dealer.component.html',
  styleUrls: ['./dealer.component.css']
})
export class DealerComponent implements OnInit {

  constructor(private service: DealerService) { }
  loginDealer(form: NgForm) {
    this.service.loginDealer(form.value).subscribe(data => {
      console.log('hi');
      console.log(data);
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
