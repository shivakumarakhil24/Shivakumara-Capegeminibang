import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:8080';

  loginAdmin(data) {
    return this.http.post<any>(`${this.url}/adminLogin`, data);
  }

  addManufacturer(data) {
    return this.http.put(`${this.url}/addmanufacture`, data);
  }
  modifyManufacturer(data) {
    return this.http.post(`${this.url}/updateManufacture`, data);
  }
  removeManufacturer(userId) {
    return this.http.delete(`${this.url}/deleteManufacture/${userId}`);
  }

  getAllManufacture() {
    return this.http.get<any>(`${this.url}/getAllManufacture`);
  }
}
