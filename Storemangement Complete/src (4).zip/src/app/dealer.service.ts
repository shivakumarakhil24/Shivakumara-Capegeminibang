import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DealerService {


  constructor(private http: HttpClient) { }
  url = 'http://localhost:8080';


  showAllProducts() {
    return this.http.get<any>(`${this.url}/showAllProducts`);
  }
  orderProduct(data) {
    return this.http.put<any>(`${this.url}/placeOrder`, data);
  }

  loginDealer(data) {
    return this.http.post(`${this.url}/loginDealer`, data);
  }
  viewStore(storeId) {
    return this.http.get(`${this.url}/viewMyStore/${storeId}`, storeId);
  }
   viewMyOrder(userId) {
     return this.http.get(`${this.url}/myOrders/${userId}`, userId);
   }

  cancelOrder(referenceId) {
    return this.http.delete(`${this.url}/cancelOrder/${referenceId}`);
  }
}
