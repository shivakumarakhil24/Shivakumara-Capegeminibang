import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css']
})
export class AddProductsComponent implements OnInit {

  constructor(private service: ManufacturerService, private router: Router) { }

  AddProduct(form: NgForm) {
    this.service.addProduct(form.value).subscribe(data => {
      console.log(data);
      this.router.navigateByUrl('/manufacturer');
      this.service.getAllProducts();
      form.reset();
    }, err => {
      console.log(err);
    }, () => {
      console.log('added Successfully');
      alert ('product added successfully');
    });
  }


  ngOnInit() {
  }

}
