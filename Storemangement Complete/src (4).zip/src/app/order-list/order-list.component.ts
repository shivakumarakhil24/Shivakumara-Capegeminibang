import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {
  Orders = {
    orderId: null,
    productId: null,
    userId: null,
    quantity: null,
    location: null,
  };

  orders: any[];
  constructor(private service: ManufacturerService) {
    this.viewAllOrders();
  }

  viewAllOrders() {
    this.service.viewAllOrders().subscribe(order => {
      console.log(order);
      this.orders = order;
    }, err => {
      console.log(err);
    }, () => {
      console.log('completed successfully');
    });
  }

  ngOnInit() {
  }

}







