import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css']
})
export class StoreComponent implements OnInit {

  Stores = {
    stotreId: null,
    productId: null,
    no_of_items: null,
    minimumStockMantain: null,
  };

  stores: any[];
  constructor(private service: ManufacturerService) {
    this.viewAllStore();
  }

  viewAllStore() {
    this.service.viewStore().subscribe(store => {
      console.log(store);
      this.stores = store;
    }, err => {
      console.log(err);
    }, () => {
      console.log('completed successfully');
    });
  }

  ngOnInit() {
  }
  
}
