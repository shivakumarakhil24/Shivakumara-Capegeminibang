import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private service: AdminService) { }
  loginAdmin(form: NgForm) {
    this.service.loginAdmin(form.value).subscribe(data => {
      console.log('hi');
      console.log(data);
    }, err => {
      console.log(err);
    });
  }

  ngOnInit() {
  }

}
