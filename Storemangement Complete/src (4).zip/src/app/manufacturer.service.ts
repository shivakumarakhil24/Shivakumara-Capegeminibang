import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ManufacturerService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:8080';

  addProduct(data) {
    return this.http.put(`${this.url}/addProducts`, data);
  }
  getAllProducts() {
    return this.http.get<any>(`${this.url}/getAllProducts`);
  }

  updateProduct(data) {
    return this.http.post(`${this.url}/updateProducts`, data);
  }

  deleteProduct(productId) {
    return this.http.delete(`${this.url}/deleteProduct/${productId}`);
  }

  addDealer(data) {
    return this.http.put(`${this.url}/addDealer`, data);
  }

  viewAllDealer() {
    return this.http.get<any>(`${this.url}/getAllDealers`);
  }

  updateDealer(data) {
    return this.http.post(`${this.url}/updateDealer`, data);
  }

  loginManufact(data) {
    return this.http.post(`${this.url}/manufacturLogin`, data);
  }
  deleteDealer(userId) {
    return this.http.delete(`${this.url}/deleteDealer/${userId}`);
  }
  viewAllOrders() {
    return this.http.get<any>(`${this.url}/getAllOrders`);
  }
  viewStore() {
    return this.http.get<any>(`${this.url}/viewStore`);
  }




 
}
