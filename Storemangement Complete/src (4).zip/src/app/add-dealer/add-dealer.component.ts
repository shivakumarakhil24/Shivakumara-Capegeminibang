import { Component, OnInit, ɵConsole } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ManufacturerService } from '../manufacturer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-dealer',
  templateUrl: './add-dealer.component.html',
  styleUrls: ['./add-dealer.component.css']
})
export class AddDealerComponent implements OnInit {

  constructor(private service: ManufacturerService , private router : Router) { }



  AddDealer(form: NgForm) {
    console.log(form.value);
    this.service.addDealer(form.value).subscribe(data => {
      console.log(data);
      this.router.navigateByUrl('dealerList');

    }, err => {
      console.log(err);
    }, () => {
      console.log('Dealer Added Successfully');
    });
  }


 

  ngOnInit() {
  }

}
