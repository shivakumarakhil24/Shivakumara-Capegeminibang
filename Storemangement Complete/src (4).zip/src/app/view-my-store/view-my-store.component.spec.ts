import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMyStoreComponent } from './view-my-store.component';

describe('ViewMyStoreComponent', () => {
  let component: ViewMyStoreComponent;
  let fixture: ComponentFixture<ViewMyStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMyStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMyStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
