package com.capgemini.universittyjdbc.jdbc;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.beans.ProgramsScheduled;
import com.capgemini.universittyjdbc.beans.Users;
import com.capgemini.universittyjdbc.dao.ApplicantDaoImpl;
import com.capgemini.universittyjdbc.services.AdminService;
import com.capgemini.universittyjdbc.services.AdminServiceImpl;
import com.capgemini.universittyjdbc.services.ApplicantService;
import com.capgemini.universittyjdbc.services.ApplicantServiceImpl;

import com.capgemini.universittyjdbc.services.MacService;
import com.capgemini.universittyjdbc.services.MacServiceImpl;
import com.capgemini.universittyjdbc.validation.RegexValidation;

public class App {
	private static Scanner sc = new Scanner(System.in);
	private static RegexValidation regVal=new RegexValidation();
	private static AdminService adminService = new AdminServiceImpl();
	private static ApplicantService applicantService = new ApplicantServiceImpl();
	private static MacService committeeService = new MacServiceImpl();

	public static void main(String[] args) {
//Validation:-  userId String (name)
         //  password String + int (pass123)
		//  Email String + @ + . + string (email@xx.com)
		//  Date Format [yyyy-mm-dd] 
		
		System.out.println("Welcome to University Admission");

		System.out.println("------------------------------------------");
		int loginChoice;
		do {
			System.out.println("Select Type of Login");
			System.out.println("1.Users");
			System.out.println("2.Applicant");
			System.out.println("3.Participant");
			System.out.println("0.Exit");
			System.out.print("Enter your choice: ");
			loginChoice = sc.nextInt();
			

			switch (loginChoice) {
			case 1:
				Users user = new Users();

				System.out.println("Enter the user ID : ");
				String id=regVal.regexId(sc.next());
				while(id==null) {
					System.out.println("Invalid ID format: Enter proper format");
					id = regVal.regexId(sc.next());
				}
				user.setLoginId(id);
				System.out.println("Enter the login password");
				String pw=regVal.regexPassword(sc.next());
				user.setPassword(pw);
				System.out.println("Enter the role");
				String role=regVal.regexRole(sc.next());
				user.setRole(role);
				boolean adminLoggedIn = adminService.login(user);
				boolean macLoggedIn = committeeService.login(user);
				if (adminLoggedIn) {
					System.out.println("Welcome to admin");
					adminOperations();
				} else if (macLoggedIn) {
					System.out.println("Welcome to mac");
				    macOperations();
				} else {
					System.out.println("Enter the proper credentials");
				}

				break;
			case 2:
				System.out.println("welcome to aspirant");
				applicantOperations();
				break;
			case 3:
				System.out.println("Welcome to Participants\n\n");
				System.out.println("Enter the application ID to view status ");
				int applicationID = sc.nextInt();
				Application viewStatus = applicantService.viewStatus(applicationID);
				System.out.println(viewStatus);

			} // end of switch

		} while (loginChoice != 0);
	}

	private static void adminOperations() {
		int selectChoice;
		do {
			System.out.println("1) addProgramsOffered");
			System.out.println("2) updateProgramsOffered");
			System.out.println("3) deleteProgramsOffered");
			System.out.println("4) addProgramsScheduled");
			System.out.println("5) updatePramsScheduled");
			System.out.println("6) deleteProgramsScheduled");
			System.out.println("7) viewAllAcceptedApplications");
			System.out.println("8) viewAllConfirmedApplications");
			System.out.println("9) viewAllRejectedApplications");
			System.out.println("0) Go Back");
			System.out.println("Enter the choice");
			System.out.println();
			selectChoice = sc.nextInt();
			switch (selectChoice) {
			case 1:
				// addProgramsOffered
				ProgramsOffered addProgramOffered = new ProgramsOffered();
				System.out.println("Enter programe name ");
				addProgramOffered.setProgramName(sc.next());
				System.out.println("Enter the programme description");
				addProgramOffered.setDescription(sc.next());
				System.out.println("Enter the applicant eligibility");
				addProgramOffered.setApplicantEligibility(sc.nextDouble());
				System.out.println("Enter the duartion");
				addProgramOffered.setDuration(sc.next());
				System.out.println("Enter the DegreeCertificateOffered");
				addProgramOffered.setDegreeCertificateOffered(sc.next());
				boolean addProgram = adminService.addProgramsOffered(addProgramOffered);
				if (addProgram) {
					System.out.println("Programme added successfully");
				} else {
					System.out.println("Programme is not added succesfully");
				}
				break;
			case 2:
				// updateProgramsOffered
				ProgramsOffered updateProgram = new ProgramsOffered();
				System.out.println("Enter the programe name to be updated ");
				updateProgram.setProgramName(sc.next());
				System.out.println("Enter the  programme description");
				updateProgram.setDescription(sc.next());
				System.out.println("Enter the applicant eligibility");
				updateProgram.setApplicantEligibility(sc.nextDouble());
				System.out.println("Enter the duartion");
				updateProgram.setDuration(sc.next());
				System.out.println("Enter the DegreeCertificateOffered");
				updateProgram.setDegreeCertificateOffered(sc.next());
				boolean updatePgm = adminService.updateProgramsOffered(updateProgram);
				if (updatePgm) {
					System.out.println("Programme update successfully");
				} else {
					System.out.println("Updation failed");
				}
				break;
			case 3:
				System.out.println("Enter the Programme Name to delete ");
				String delProgram = sc.next();
				boolean deletedPgm = adminService.deleteProgramsOffered(delProgram);
				if (deletedPgm) {
					System.out.println("Programme deleted successfully");
				} else {
					System.out.println("Deleted failed");
				}
				break;
			case 4:
				// addProgramsScheduled
				ProgramsScheduled programsScheduled = new ProgramsScheduled();
				System.out.println("Enter the scheduledProgramId");
				programsScheduled.setScheduledProgramId(sc.next());
				System.out.println("Enter the programme Name");
				programsScheduled.setProgramName(sc.next());
				System.out.println("Enter the location");
				programsScheduled.setLocation(sc.next());
				System.out.println("Enter the start date [yyyy-mm-dd]");
				String sDate=regVal.regexDob(sc.next());
				programsScheduled.setStartDate(sDate);
				System.out.println("Enter the End date [yyyy-mm-dd]");
				String eDate=regVal.regexDob(sc.next());
				programsScheduled.setEndDate(eDate);
				System.out.println("Enter the session per week");
				programsScheduled.setSessionPerWeek(sc.nextInt());
				boolean addScheduled = adminService.addProgramsScheduled(programsScheduled);
				if (addScheduled) {
					System.out.println("Programme scheduled successfully ");
				} else {
					System.out.println("failed");
				}
				break;
			case 5:
				// Update program scheduled
				ProgramsScheduled updateProgramScheduled = new ProgramsScheduled();
				System.out.println("Enter the scheduledProgramId to be Updated");
				updateProgramScheduled.setScheduledProgramId(sc.next());
				System.out.println("Enter the programme Name");
				updateProgramScheduled.setProgramName(sc.next());
				System.out.println("Enter the location");
				updateProgramScheduled.setLocation(sc.next());
				System.out.println("Enter the start date [yyyy-mm-dd] ");
				updateProgramScheduled.setStartDate(sc.next());
				System.out.println("Enter the End date [yyyy-mm-dd]");
				updateProgramScheduled.setEndDate(sc.next());
				System.out.println("Enter the session per week");
				updateProgramScheduled.setSessionPerWeek(sc.nextInt());
				boolean updateScheduled = adminService.updateProgramsScheduled(updateProgramScheduled);
				if (updateScheduled) {
					System.out.println("Programme  scheduled  updated successfully ");
				} else {
					System.out.println("failed");
				}
				break;
			case 6:
				System.out.println("Enter the scheduled programID to delete ");
				String scheduledProgramId = sc.next();
				boolean deleteScheduled = adminService.deleteProgramsScheduled(scheduledProgramId);
				if (deleteScheduled) {
					System.out.println("programe schedule deleted");
				} else {
					System.out.println("failed to deleted");
				}
				break;
			
			  case 7:  //view all accepted application status
				  List<Application> acceptedApplications = adminService.viewAllAcceptedApplications();
					for (Application application : acceptedApplications) {
						System.out.println(application);
					}
			  break;

			case 8:
				// viewAllConfirmedApplications
				List<Application> confirmedApplications = adminService.viewAllConfirmedApplications();
				for (Application application : confirmedApplications) {
					System.out.println(application);
				}
				break;
			case 9:
				// viewAllRejectedApplications
				List<Application> rejectedApplications = adminService.viewAllRejectedApplications();
				for (Application application : rejectedApplications) {
					System.out.println(application);
				}
				break;
			default:
				break;
			}
		} while (selectChoice != 0);
	}

	private static void macOperations() {
		int selectChoice;
		MacService service = new MacServiceImpl();
		do {
			System.out.println("1) view all application ");
			System.out.println("2) Modify Status");
			System.out.println("0) Go Back");
			System.out.println("Enter the choice");
			System.out.println();
			selectChoice = sc.nextInt();
			switch (selectChoice) {
			case 1:
				System.out.println("Enter specific Scheduled Id :");
				String scheduledProgramId = sc.next();
				List<Application> applications = service.viewAllApplications(scheduledProgramId);
				for (Application application : applications) {
					System.out.println(application);
				}
				break;

			case 2:
				System.out.println("Enter application Id needed to be modified");
				int id=sc.nextInt();
				System.out.println("Set the status this student [Confirmed or Rejected]");
				String status = sc.next();
			    System.out.println("Enter the date of interview [yyyy-mm-dd]");
			    String interView=sc.next(); 
				String status1 = committeeService.modifyStatus(id, status, interView);
				if ( status !=null) {
					System.out.println("Student is "+status1+" Date of interview "+interView);
				} else {
					System.out.println("Application might not exist");
				}
				break;
			default:
				break;
			}
		} while (selectChoice != 0);
	}

	private static void applicantOperations() {
		int choice;
		ApplicantDaoImpl appManager = new ApplicantDaoImpl();
		do {
			System.out.println("1) Program offered");
			System.out.println("2) Program scheduled");
			System.out.println("3) To apply");
			System.out.println("0) Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Program offered");
				List<ProgramsOffered> programs;
				programs = appManager.viewAllPrograms();
				Iterator<ProgramsOffered> it = programs.iterator();
				while (it.hasNext()) {
					ProgramsOffered program = (ProgramsOffered) it.next();
					System.out.println(program);
				}
			  break;
			case 2:
				System.out.println("Progrmas Scheduled");
				List<ProgramsScheduled> scheduleds;
				scheduleds = appManager.viewAllProgramScheduled();
				Iterator<ProgramsScheduled> it2 = scheduleds.iterator();
				while (it2.hasNext()) {
					ProgramsScheduled scheduled = (ProgramsScheduled) it2.next();
					System.out.println(scheduled);
				}
				break;
			case 3:
				Application application = new Application();
				System.out.println("Enter the applicant name ");
				application.setFullName(sc.next());
				System.out.println("Enter the date of birth ");
				String dob =regVal.regexDob(sc.next());
				application.setDateOfBirth(dob);
				System.out.println("Enter the highest qualification ");
				application.setHighestQualification(sc.next());
				System.out.println("Enter the marks obtained ");
				application.setMarksObtained(sc.nextInt());
				System.out.println("Enter the email Id");
				application.setEmailId(sc.next());
				System.out.println("Enter the goals ");
				application.setGoals(sc.next());
				System.out.println("Enter ProgramScheduled ID");
				application.setScheduledProgramId(sc.next());
				int applicationId = appManager.apply(application);
				System.out.println("View your application: " + applicationId
						+ ".\n Please note application Id ");
				
			default:
				break;
			}
		} while (choice != 0);

	}
}
