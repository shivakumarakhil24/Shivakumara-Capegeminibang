package com.capgemini.universittyjdbc.exceptions;

public class SetDateException extends RuntimeException {
	public SetDateException() {
		System.out.println("something went wrong");
	}
}
