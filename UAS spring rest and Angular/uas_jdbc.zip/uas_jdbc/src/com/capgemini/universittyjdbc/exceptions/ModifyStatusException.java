package com.capgemini.universittyjdbc.exceptions;

public class ModifyStatusException extends RuntimeException{
	public ModifyStatusException() {
		System.out.println("Modification is failed");
	}

}
