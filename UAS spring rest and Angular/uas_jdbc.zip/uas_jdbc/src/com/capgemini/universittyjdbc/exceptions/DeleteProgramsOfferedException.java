package com.capgemini.universittyjdbc.exceptions;

public class DeleteProgramsOfferedException extends RuntimeException{
	public DeleteProgramsOfferedException() {
		System.out.println("something went wrong");
	}

}
