package com.capgemini.universittyjdbc.exceptions;

public class ViewAllConfirmedApplicationException extends RuntimeException{

	public ViewAllConfirmedApplicationException() {
		System.out.println("something went wrong");
	}
}
