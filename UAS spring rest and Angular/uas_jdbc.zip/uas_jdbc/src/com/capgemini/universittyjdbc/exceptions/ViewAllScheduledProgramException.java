package com.capgemini.universittyjdbc.exceptions;

public class ViewAllScheduledProgramException extends RuntimeException{
	public ViewAllScheduledProgramException() {
		System.out.println("something went wrong");
	}

}
