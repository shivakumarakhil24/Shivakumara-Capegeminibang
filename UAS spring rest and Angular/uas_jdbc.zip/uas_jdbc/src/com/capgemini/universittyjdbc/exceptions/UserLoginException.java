package com.capgemini.universittyjdbc.exceptions;

public class UserLoginException extends RuntimeException{

	public UserLoginException() {
		System.out.println("Enter valid id and password");
	}
	
	
	
}
