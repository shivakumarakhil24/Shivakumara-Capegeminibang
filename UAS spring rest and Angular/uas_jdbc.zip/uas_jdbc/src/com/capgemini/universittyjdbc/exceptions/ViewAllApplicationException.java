package com.capgemini.universittyjdbc.exceptions;

public class ViewAllApplicationException extends RuntimeException {
	public ViewAllApplicationException() {
		
	}

}
