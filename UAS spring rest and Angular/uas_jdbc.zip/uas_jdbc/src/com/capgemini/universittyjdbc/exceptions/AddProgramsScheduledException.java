package com.capgemini.universittyjdbc.exceptions;

public class AddProgramsScheduledException extends RuntimeException{
	
	public AddProgramsScheduledException() {
		System.out.println("something went wrong");
	}

}
