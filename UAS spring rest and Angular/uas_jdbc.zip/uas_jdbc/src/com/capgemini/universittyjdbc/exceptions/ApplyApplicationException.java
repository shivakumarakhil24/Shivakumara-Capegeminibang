package com.capgemini.universittyjdbc.exceptions;

public class ApplyApplicationException extends RuntimeException {
	public ApplyApplicationException() {
		System.out.println("something went wrong");
	}

}
