package com.capgemini.universittyjdbc.exceptions;

public class UpdateProgramsScheduledException extends RuntimeException {
	public UpdateProgramsScheduledException() {
		System.out.println("something went wrong");
	}

}
