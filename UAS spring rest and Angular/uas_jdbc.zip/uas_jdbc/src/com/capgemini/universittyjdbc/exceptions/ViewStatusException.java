package com.capgemini.universittyjdbc.exceptions;

public class ViewStatusException extends RuntimeException {
	public ViewStatusException() {
		System.out.println("something went wrong");
	}

}
