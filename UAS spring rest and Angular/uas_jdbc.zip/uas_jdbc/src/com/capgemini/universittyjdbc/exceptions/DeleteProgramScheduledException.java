package com.capgemini.universittyjdbc.exceptions;

public class DeleteProgramScheduledException extends RuntimeException{
	public DeleteProgramScheduledException() {
		System.out.println("something went wrong");
	}

}
