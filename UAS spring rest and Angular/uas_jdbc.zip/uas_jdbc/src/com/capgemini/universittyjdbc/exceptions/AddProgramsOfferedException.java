package com.capgemini.universittyjdbc.exceptions;

public class AddProgramsOfferedException extends RuntimeException {
	
	public AddProgramsOfferedException(){
		
		System.out.println("something went wrong");
		
	}

}
