package com.capgemini.universittyjdbc.exceptions;

public class ApplicationModifyException extends RuntimeException{
	
	public ApplicationModifyException() {
		System.out.println("something went wrong");
	}

}
