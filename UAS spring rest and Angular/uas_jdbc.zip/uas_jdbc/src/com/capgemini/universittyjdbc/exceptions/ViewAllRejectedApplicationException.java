package com.capgemini.universittyjdbc.exceptions;

public class ViewAllRejectedApplicationException extends RuntimeException {
	public ViewAllRejectedApplicationException() {
		System.out.println("something went wrong");
	}

}
