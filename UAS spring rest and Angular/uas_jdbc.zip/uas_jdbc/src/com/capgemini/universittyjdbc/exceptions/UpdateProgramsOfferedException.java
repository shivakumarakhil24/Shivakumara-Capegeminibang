package com.capgemini.universittyjdbc.exceptions;

public class UpdateProgramsOfferedException extends RuntimeException {
	public UpdateProgramsOfferedException() {
		System.out.println("something went wrong");
	}

}
