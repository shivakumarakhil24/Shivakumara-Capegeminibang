package com.capgemini.universittyjdbc.exceptions;

public class ViewAllProgramException extends RuntimeException {
	public ViewAllProgramException() {
		System.out.println("something went wrong");
	}

}
