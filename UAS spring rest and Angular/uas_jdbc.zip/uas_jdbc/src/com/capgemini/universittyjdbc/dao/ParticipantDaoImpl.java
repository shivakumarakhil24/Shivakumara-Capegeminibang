package com.capgemini.universittyjdbc.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;


import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;

public class ParticipantDaoImpl implements ParticipantDao {

	@Override
	public Application viewStatus(int applicationId) throws ViewStatusException {
		Application application =new Application();
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql="select * from application where application_id=?";;

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);){
				
				preparedStatement.setInt(1, applicationId);
				
				try(ResultSet resultSet = preparedStatement.executeQuery();){
					if(resultSet.next()) {
						application=new Application();
						application.setApplicationId(resultSet.getInt("application_id"));
						application.setFullName(resultSet.getString("full_name"));
						application.setDateOfBirth(resultSet.getString("date_of_birth"));
						application.setHighestQualification(resultSet.getString("highest_qualification"));
						application.setMarksObtained(resultSet.getInt("marks_obtained"));
						application.setGoals(resultSet.getString("goal"));
						application.setEmailId(resultSet.getString("eamil_id"));
						application.setScheduledProgramId(resultSet.getString("scheduled_program_id"));
						application.setStatus(resultSet.getString("status"));
						application.setDateOfInterview(resultSet.getString("date_of_interview"));
					}
				}
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return application;	
		
	}

}
