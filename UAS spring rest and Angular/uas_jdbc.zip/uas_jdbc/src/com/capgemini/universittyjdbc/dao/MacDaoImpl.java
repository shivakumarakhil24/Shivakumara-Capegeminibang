package com.capgemini.universittyjdbc.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.Users;
import com.capgemini.universittyjdbc.exceptions.ModifyStatusException;
import com.capgemini.universittyjdbc.exceptions.UserLoginException;
import com.capgemini.universittyjdbc.exceptions.ViewAllApplicationException;

public class MacDaoImpl implements MacDao {

	Users user = new Users();

	@Override
	public boolean login(Users user) throws UserLoginException {

		boolean logged = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from user where login_id = ? and password = ? and role = ?;";

			Class.forName(properties.getProperty("drivername"));

			try (Connection conn = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = conn.prepareStatement(sql);) {
				preparedStatement.setString(1, user.getLoginId());
				preparedStatement.setString(2, user.getPassword());
				preparedStatement.setString(3, user.getRole());
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					if (resultSet.next() && user.getRole().equals("mac")) {
						logged = true;

					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return logged;
	}

	@Override
	public List<Application> viewAllApplications(String scheduledProgramId) throws ViewAllApplicationException{
		List<Application> application = new ArrayList<Application>();
		Application app;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "select * from application where scheduled_program_id=?";
			;

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(1, scheduledProgramId);

				try (ResultSet resultSet = preparedStatement.executeQuery();) {
					while (resultSet.next()) {
						app = new Application();
						app.setApplicationId(resultSet.getInt("application_id"));
						app.setFullName(resultSet.getString("full_name"));
						app.setDateOfBirth(resultSet.getString("date_of_birth"));
						app.setHighestQualification(resultSet.getString("highest_qualification"));
						app.setMarksObtained(resultSet.getInt("marks_obtained"));
						app.setGoals(resultSet.getString("goal"));
						app.setEmailId(resultSet.getString("eamil_id"));
						app.setScheduledProgramId(resultSet.getString("scheduled_program_id"));
						app.setStatus(resultSet.getString("status"));
						app.setDateOfInterview(resultSet.getString("date_of_interview"));
						application.add(app);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return application;
	}

	@Override
	public String modifyStatus(int applicationId, String status,String dateOfiInterview) throws ModifyStatusException{
		boolean modified = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Update application set status=?,date_of_interview=? where application_id=?";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(1, status);
				preparedStatement.setString(2, dateOfiInterview);
				preparedStatement.setInt(3, applicationId);
				

				int count = preparedStatement.executeUpdate();
				if (count > 0) {
					modified = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (modified) {
			return status;
		}
		return null;

	}

}
