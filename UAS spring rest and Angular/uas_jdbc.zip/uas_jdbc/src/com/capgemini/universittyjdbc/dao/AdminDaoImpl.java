package com.capgemini.universittyjdbc.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.beans.ProgramsScheduled;
import com.capgemini.universittyjdbc.beans.Users;
import com.capgemini.universittyjdbc.exceptions.AddProgramsOfferedException;
import com.capgemini.universittyjdbc.exceptions.AddProgramsScheduledException;
import com.capgemini.universittyjdbc.exceptions.DeleteProgramScheduledException;
import com.capgemini.universittyjdbc.exceptions.DeleteProgramsOfferedException;
import com.capgemini.universittyjdbc.exceptions.UpdateProgramsOfferedException;
import com.capgemini.universittyjdbc.exceptions.UpdateProgramsScheduledException;
import com.capgemini.universittyjdbc.exceptions.UserLoginException;
import com.capgemini.universittyjdbc.exceptions.ViewAllAcceptedApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllConfirmedApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllRejectedApplicationException;

public class AdminDaoImpl implements AdminDao {

	@Override
	public boolean login(Users user) throws UserLoginException{

		boolean logged = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "select * from user where login_Id=? and password =? and role=?;";

			Class.forName(properties.getProperty("drivername"));

			try (Connection conn = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = conn.prepareStatement(sql);) {
				preparedStatement.setString(1, user.getLoginId());
				preparedStatement.setString(2, user.getPassword());
				preparedStatement.setString(3, user.getRole());
				
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					if (resultSet.next() && user.getRole().equals("admin")) {
						logged = true;

					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return logged;
	}

	@Override
	public boolean addProgramsOffered(ProgramsOffered program) throws AddProgramsOfferedException{
		boolean addProgram = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Insert into programs_offered values(?,?,?,?,?)";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(1, program.getProgramName());
				preparedStatement.setString(2, program.getDescription());
				preparedStatement.setDouble(3, program.getApplicantEligibility());
				preparedStatement.setString(4, program.getDuration());
				preparedStatement.setString(5, program.getDegreeCertificateOffered());

				int count = preparedStatement.executeUpdate();
				if (count > 0) {
					addProgram = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return addProgram;
	}

	@Override
	public boolean updateProgramsOffered(ProgramsOffered program) throws UpdateProgramsOfferedException{
		boolean updateProgramoffered = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Update programs_offered set description=?, applicant_eligibility=?, duration=? ,degree_certificate=?"
					+ "where progamm_name=?";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(5, program.getProgramName());
				preparedStatement.setString(1, program.getDescription());
				preparedStatement.setDouble(2, program.getApplicantEligibility());
				preparedStatement.setString(3, program.getDuration());
				preparedStatement.setString(4, program.getDegreeCertificateOffered());
				

				int count = preparedStatement.executeUpdate();
				if (count > 0) {
					updateProgramoffered = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updateProgramoffered;
	}

	@Override
	public boolean deleteProgramsOffered(String programName) throws DeleteProgramsOfferedException{
		boolean deleteProgoff=false;
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql= "Delete from programs_offered where progamm_name=?";

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);){

				preparedStatement.setString(1, programName);

				int count = preparedStatement.executeUpdate();
				if(count>0) {
					deleteProgoff= true;
				}


			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return deleteProgoff;
	}

	@Override
	public boolean addProgramsScheduled(ProgramsScheduled program) throws AddProgramsScheduledException {
		boolean addSchedule = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Insert into programscheduled values(?,?,?,?,?,?)";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(1, program.getScheduledProgramId());
				preparedStatement.setString(2, program.getProgramName());
				preparedStatement.setString(3, program.getLocation());
				preparedStatement.setString(4, program.getStartDate());
				preparedStatement.setString(5, program.getEndDate());
				preparedStatement.setInt(6, program.getSessionPerWeek());

				int count = preparedStatement.executeUpdate();
				if (count > 0) {
					addSchedule = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return addSchedule;
		
	}

	@Override
	public boolean updateProgramsScheduled(ProgramsScheduled program) throws UpdateProgramsScheduledException{
		boolean updateSchedule = false;
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Update programscheduled set program_name=?, location=?, start_date=? ,end_date=?,session_per_week=? where scheduled_program_id=?";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(1, program.getProgramName());
				preparedStatement.setString(2, program.getLocation());
				preparedStatement.setString(3, program.getStartDate());
				preparedStatement.setString(4, program.getEndDate());
				preparedStatement.setInt(5, program.getSessionPerWeek());
				preparedStatement.setString(6, program.getScheduledProgramId());
				

				int count = preparedStatement.executeUpdate();
				if (count > 0) {
					updateSchedule = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updateSchedule;
	}

	@Override
	public boolean deleteProgramsScheduled(String scheduledProgramId) throws DeleteProgramScheduledException{
		boolean deleteProgSchedule=false;
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql= "Delete from programscheduled where scheduled_program_id=?";

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);){

				preparedStatement.setString(1, scheduledProgramId);

				int count = preparedStatement.executeUpdate();
				if(count>0) {
					deleteProgSchedule= true;
				}


			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return deleteProgSchedule;
	}
	

	@Override
	public List<Application> viewAllAcceptedApplications() throws ViewAllAcceptedApplicationException{
		List<Application> allaccept =new ArrayList<Application>();
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql= "Select * from application where status like 'ac%';";

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)){
				
				while(resultSet.next()) {
					Application app = new Application();
					
					app.setApplicationId(resultSet.getInt("application_id"));
					app.setFullName(resultSet.getString("full_name"));
					app.setDateOfBirth(resultSet.getString("date_of_birth"));
					app.setHighestQualification(resultSet.getString("highest_qualification"));
					app.setMarksObtained(resultSet.getInt("marks_obtained"));
					app.setGoals(resultSet.getString("goal"));
					app.setEmailId(resultSet.getString("eamil_id"));
					app.setScheduledProgramId(resultSet.getString("scheduled_program_id"));
					app.setStatus(resultSet.getString("status"));
					
					
				
					allaccept.add(app);
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return allaccept;
	};
	

	@Override
	public List<Application> viewAllConfirmedApplications() throws ViewAllConfirmedApplicationException{
		List<Application> allConfirm =new ArrayList<Application>();
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql= "Select * from application where status like 'c%' ";

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)){
				
				while(resultSet.next()) {
					Application app = new Application();
					
					app.setApplicationId(resultSet.getInt("application_id"));
					app.setFullName(resultSet.getString("full_name"));
					app.setDateOfBirth(resultSet.getString("date_of_birth"));
					app.setHighestQualification(resultSet.getString("highest_qualification"));
					app.setMarksObtained(resultSet.getInt("marks_obtained"));
					app.setGoals(resultSet.getString("goal"));
					app.setEmailId(resultSet.getString("eamil_id"));
					app.setScheduledProgramId(resultSet.getString("scheduled_program_id"));
					app.setStatus(resultSet.getString("status"));
					
					
				
					allConfirm.add(app);
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return allConfirm;
		
	}

	@Override
	public List<Application> viewAllRejectedApplications() throws ViewAllRejectedApplicationException{
		List<Application> allreject =new ArrayList<Application>();
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql= "Select * from application where status like 'r%' ";

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)){
				
				while(resultSet.next()) {
					Application app = new Application();
					
					app.setApplicationId(resultSet.getInt("application_id"));
					app.setFullName(resultSet.getString("full_name"));
					app.setDateOfBirth(resultSet.getString("date_of_birth"));
					app.setHighestQualification(resultSet.getString("highest_qualification"));
					app.setMarksObtained(resultSet.getInt("marks_obtained"));
					app.setGoals(resultSet.getString("goal"));
					app.setEmailId(resultSet.getString("eamil_id"));
					app.setScheduledProgramId(resultSet.getString("scheduled_program_id"));
					app.setStatus(resultSet.getString("status"));
					
					
				
					allreject.add(app);
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return allreject;
		
	}

	

}
