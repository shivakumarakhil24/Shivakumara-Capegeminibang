package com.capgemini.universittyjdbc.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.beans.ProgramsScheduled;
import com.capgemini.universittyjdbc.exceptions.ApplyApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllProgramException;
import com.capgemini.universittyjdbc.exceptions.ViewAllScheduledProgramException;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;

public class ApplicantDaoImpl implements ApplicantDao {

	@Override
	public List<ProgramsOffered> viewAllPrograms() throws ViewAllProgramException{
		List<ProgramsOffered> progOfferedList = new ArrayList<ProgramsOffered>();
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from programs_offered";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)) {

				while (resultSet.next()) {
					ProgramsOffered offerred = new ProgramsOffered();

					offerred.setProgramName(resultSet.getString("progamm_name"));
					offerred.setDescription(resultSet.getString("description"));
					offerred.setApplicantEligibility(resultSet.getDouble("applicant_eligibility"));
					offerred.setDuration(resultSet.getString("duration"));
					offerred.setDegreeCertificateOffered(resultSet.getString("degree_certificate"));

					progOfferedList.add(offerred);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return progOfferedList;
		
	}

	@Override
	public List<ProgramsScheduled> viewAllProgramScheduled() throws ViewAllProgramException{
		List<ProgramsScheduled> progScheduleList = new ArrayList<ProgramsScheduled>();
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from programscheduled";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)) {

				while (resultSet.next()) {
					ProgramsScheduled scheduled = new ProgramsScheduled();

					scheduled.setProgramName(resultSet.getString("program_name"));
					scheduled.setScheduledProgramId(resultSet.getString("scheduled_program_id"));;
					scheduled.setLocation(resultSet.getString("location"));
					scheduled.setStartDate(resultSet.getString("start_date"));
					scheduled.setEndDate(resultSet.getString("end_date"));
					scheduled.setSessionPerWeek(resultSet.getInt("session_per_week"));

					progScheduleList.add(scheduled);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return progScheduleList;
	}

	@Override
	public int apply(Application application) throws ApplyApplicationException{
		boolean isApplied=false;
		int applicationId= 0;
		
		 Application app = new Application();
		 
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Insert into application (full_name,date_of_birth,highest_qualification,marks_obtained,goal,eamil_id,scheduled_program_id) values(?,?,?,?,?,?,?)";
			String sql2="select application_id from application where eamil_id=?";

			Class.forName(properties.getProperty("drivername"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);
					PreparedStatement preparedStatement2 = connection.prepareStatement(sql2);){

				preparedStatement.setString(1, application.getFullName());
				preparedStatement.setString(2, application.getDateOfBirth());
				preparedStatement.setString(3, application.getHighestQualification());
				preparedStatement.setDouble(4, application.getMarksObtained());
				preparedStatement.setString(5, application.getGoals());
				preparedStatement.setString(6, application.getEmailId());
				preparedStatement.setString(7, application.getScheduledProgramId());

				int count = preparedStatement.executeUpdate();
				
				preparedStatement2.setString(1, application.getEmailId());
				
				try(ResultSet resultSet = preparedStatement2.executeQuery()){
					if(resultSet.next()) {
						applicationId =  resultSet.getInt("application_id");
					}
				}
				if (count > 0) {
					isApplied=true;
					
				}
			} 
		}catch (Exception e) {
			e.printStackTrace();
		}
	
		return applicationId;
	} 

	@Override
	public Application viewStatus(int applicationId)throws ViewStatusException {
		
		Application application =new Application();
		try(FileInputStream stream = new FileInputStream("jdbc.properties")){
			Properties properties = new Properties();
			properties.load(stream);

			String url=properties.getProperty("url");
			String sql="select * from application where application_id=?";;

			Class.forName(properties.getProperty("drivername"));

			try(Connection connection= DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);){
				
				preparedStatement.setInt(1, applicationId);
				
				try(ResultSet resultSet = preparedStatement.executeQuery();){
					if(resultSet.next()) {
						application=new Application();
						application.setApplicationId(resultSet.getInt("application_id"));
						application.setFullName(resultSet.getString("full_name"));
						application.setDateOfBirth(resultSet.getString("date_of_birth"));
						application.setHighestQualification(resultSet.getString("highest_qualification"));
						application.setMarksObtained(resultSet.getInt("marks_obtained"));
						application.setGoals(resultSet.getString("goal"));
						application.setEmailId(resultSet.getString("eamil_id"));
						application.setScheduledProgramId(resultSet.getString("scheduled_program_id"));
						application.setStatus(resultSet.getString("status"));
						application.setDateOfInterview(resultSet.getString("date_of_interview"));
					}
				}
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return application;	
		
	}

}
