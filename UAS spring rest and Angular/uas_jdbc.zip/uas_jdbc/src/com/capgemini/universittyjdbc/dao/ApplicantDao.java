package com.capgemini.universittyjdbc.dao;

import java.util.List;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.beans.ProgramsScheduled;
import com.capgemini.universittyjdbc.exceptions.ApplyApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllProgramException;
import com.capgemini.universittyjdbc.exceptions.ViewAllScheduledProgramException;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;


public interface ApplicantDao {
	
	public List<ProgramsOffered> viewAllPrograms() throws ViewAllProgramException;
	public List<ProgramsScheduled> viewAllProgramScheduled() throws ViewAllScheduledProgramException;
	public  int apply(Application application) throws ApplyApplicationException;
	public Application  viewStatus(int applicationId) throws ViewStatusException;
}
