package com.capgemini.universittyjdbc.dao;

import javax.swing.plaf.basic.BasicScrollPaneUI.VSBChangeListener;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;

public interface ParticipantDao {
	public Application  viewStatus(int applicationId) throws ViewStatusException;

}
