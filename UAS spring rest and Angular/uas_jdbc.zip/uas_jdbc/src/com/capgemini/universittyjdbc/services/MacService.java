package com.capgemini.universittyjdbc.services;

import java.util.List;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.Users;
import com.capgemini.universittyjdbc.exceptions.ModifyStatusException;
import com.capgemini.universittyjdbc.exceptions.UserLoginException;
import com.capgemini.universittyjdbc.exceptions.ViewAllApplicationException;

public interface MacService {
	
	public boolean login(Users user) throws UserLoginException;
	public List<Application> viewAllApplications(String scheduledProgramId) throws ViewAllApplicationException;
	public String modifyStatus(int applicationId, String status,String dateOfiInterview) throws ModifyStatusException;

}
