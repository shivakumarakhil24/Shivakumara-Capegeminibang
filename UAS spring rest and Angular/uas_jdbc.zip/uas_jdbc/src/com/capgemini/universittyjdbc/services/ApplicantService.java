package com.capgemini.universittyjdbc.services;

import java.util.List;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.exceptions.ApplyApplicationException;
import com.capgemini.universittyjdbc.exceptions.UserLoginException;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;


public interface ApplicantService {

	public List<ProgramsOffered> viewAllPrograms() throws UserLoginException ;
	public Application viewStatus(int applicationId) throws ViewStatusException;
	public int apply(Application application) throws ApplyApplicationException;
}
