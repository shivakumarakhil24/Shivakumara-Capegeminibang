package com.capgemini.universittyjdbc.services;

import java.util.List;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.beans.ProgramsScheduled;
import com.capgemini.universittyjdbc.beans.Users;
import com.capgemini.universittyjdbc.dao.AdminDao;
import com.capgemini.universittyjdbc.dao.AdminDaoImpl;
import com.capgemini.universittyjdbc.exceptions.AddProgramsOfferedException;
import com.capgemini.universittyjdbc.exceptions.AddProgramsScheduledException;
import com.capgemini.universittyjdbc.exceptions.DeleteProgramScheduledException;
import com.capgemini.universittyjdbc.exceptions.DeleteProgramsOfferedException;
import com.capgemini.universittyjdbc.exceptions.UpdateProgramsOfferedException;
import com.capgemini.universittyjdbc.exceptions.UpdateProgramsScheduledException;
import com.capgemini.universittyjdbc.exceptions.UserLoginException;
import com.capgemini.universittyjdbc.exceptions.ViewAllApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllConfirmedApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllRejectedApplicationException;


public class AdminServiceImpl implements AdminService {

	AdminDao dao = new AdminDaoImpl();

	@Override
	public boolean login(Users user) throws UserLoginException {
		return dao.login(user);
	}

	@Override
	public boolean addProgramsOffered(ProgramsOffered program)throws AddProgramsOfferedException {
		return dao.addProgramsOffered(program);
	}

	@Override
	public boolean updateProgramsOffered(ProgramsOffered program) throws UpdateProgramsOfferedException{
		return dao.updateProgramsOffered(program);
	}

	@Override
	public boolean deleteProgramsOffered(String programName) throws DeleteProgramsOfferedException {
		return dao.deleteProgramsOffered(programName);
	}

	@Override
	public boolean addProgramsScheduled(ProgramsScheduled program) throws AddProgramsScheduledException{
		return dao.addProgramsScheduled(program);
	}

	@Override
	public boolean updateProgramsScheduled(ProgramsScheduled program) throws UpdateProgramsScheduledException{
		return dao.updateProgramsScheduled(program);
	}

	@Override
	public boolean deleteProgramsScheduled(String scheduledProgramId) throws DeleteProgramScheduledException{
		return dao.deleteProgramsScheduled(scheduledProgramId);
	}

	@Override
	public List<Application> viewAllAcceptedApplications() throws ViewAllApplicationException {
		return dao.viewAllAcceptedApplications();
	}

	@Override
	public List<Application> viewAllConfirmedApplications() throws ViewAllConfirmedApplicationException {
		return dao.viewAllConfirmedApplications();
	}

	@Override
	public List<Application> viewAllRejectedApplications() throws ViewAllRejectedApplicationException{
		return dao.viewAllRejectedApplications();
	}
 
}
