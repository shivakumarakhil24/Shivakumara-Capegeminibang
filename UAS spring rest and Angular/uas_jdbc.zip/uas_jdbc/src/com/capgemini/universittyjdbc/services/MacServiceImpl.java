package com.capgemini.universittyjdbc.services;

import java.util.List;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.Users;
import com.capgemini.universittyjdbc.dao.MacDao;
import com.capgemini.universittyjdbc.dao.MacDaoImpl;
import com.capgemini.universittyjdbc.exceptions.ModifyStatusException;
import com.capgemini.universittyjdbc.exceptions.UserLoginException;
import com.capgemini.universittyjdbc.exceptions.ViewAllApplicationException;


public class MacServiceImpl implements MacService {

	MacDao dao = new MacDaoImpl();

	@Override
	public boolean login(Users user) throws UserLoginException{
		return dao.login(user);
	}

	@Override
	public List<Application> viewAllApplications(String scheduledProgramId) throws ViewAllApplicationException{
		return dao.viewAllApplications(scheduledProgramId);
	}

	

	@Override
	public String modifyStatus(int applicationId, String status,String dateOfiInterview) throws ModifyStatusException{
		return dao.modifyStatus(applicationId, status,dateOfiInterview);
	}
}
