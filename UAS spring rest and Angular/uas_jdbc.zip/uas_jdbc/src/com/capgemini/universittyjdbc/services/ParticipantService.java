package com.capgemini.universittyjdbc.services;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;

public interface ParticipantService {
	public Application  viewStatus(int applicationId) throws ViewStatusException;

}
