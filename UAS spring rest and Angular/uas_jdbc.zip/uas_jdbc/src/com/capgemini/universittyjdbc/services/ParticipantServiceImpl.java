package com.capgemini.universittyjdbc.services;

import javax.swing.plaf.basic.BasicScrollPaneUI.VSBChangeListener;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.dao.ParticipantDao;
import com.capgemini.universittyjdbc.dao.ParticipantDaoImpl;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;

public class ParticipantServiceImpl implements ParticipantService { 
	ParticipantDao dao= new ParticipantDaoImpl();

	@Override
	public Application viewStatus(int applicationId) throws ViewStatusException{
		return dao.viewStatus(applicationId);
	}

}
