package com.capgemini.universittyjdbc.services;

import java.util.List;

import com.capgemini.universittyjdbc.beans.Application;
import com.capgemini.universittyjdbc.beans.ProgramsOffered;
import com.capgemini.universittyjdbc.dao.ApplicantDao;
import com.capgemini.universittyjdbc.dao.ApplicantDaoImpl;
import com.capgemini.universittyjdbc.exceptions.ApplyApplicationException;
import com.capgemini.universittyjdbc.exceptions.ViewAllProgramException;
import com.capgemini.universittyjdbc.exceptions.ViewStatusException;


public class ApplicantServiceImpl implements ApplicantService  {
	ApplicantDao dao = new ApplicantDaoImpl();

	@Override
	public List<ProgramsOffered> viewAllPrograms() throws ViewAllProgramException{
		return dao.viewAllPrograms();
	}

	@Override
	public Application viewStatus(int applicationId)throws ViewStatusException {
		return dao.viewStatus(applicationId);
	}

	@Override
	public int apply(Application application) throws ApplyApplicationException{
		return dao.apply(application);
	}

	
}
