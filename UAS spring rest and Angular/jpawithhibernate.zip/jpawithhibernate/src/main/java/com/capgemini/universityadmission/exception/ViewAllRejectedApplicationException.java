package com.capgemini.universityadmission.exception;

public class ViewAllRejectedApplicationException extends RuntimeException {
	public ViewAllRejectedApplicationException() {
		System.out.println("something went wrong");
	}

}
