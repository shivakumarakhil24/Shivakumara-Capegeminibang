package com.capgemini.uas.jpawithhibernate.dao;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;

public interface CommitteeDao {

	public boolean login(String loginId, String password,String role);
	public List<Application> viewAllApplications();
	public String editStatus(int applicationId,String status,String doi);
}
