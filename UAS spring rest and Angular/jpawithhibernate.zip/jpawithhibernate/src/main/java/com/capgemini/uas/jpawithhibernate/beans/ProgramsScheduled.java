package com.capgemini.uas.jpawithhibernate.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "programs_scheduled")
public class ProgramsScheduled {

	@Id
	@Column(name ="scheduled_program_id")
	private String scheduledProgramId;
	@Column(name = "program_name")
	private String programName;
	@Column
	private String location;
	@Column(name = "start_date")
	private String startDate;
	@Column(name = "end_date")
	private String endDate;
	@Column(name = "session_per_week")
	private String sessionPerWeek;

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSessionPerWeek() {
		return sessionPerWeek;
	}

	public void setSessionPerWeek(String sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}

	@Override
	public String toString() {
		return "ProgramsScheduled [scheduledProgramId=" + scheduledProgramId + ", programName=" + programName
				+ ", location=" + location + ", startDate=" + startDate + ", endDate=" + endDate + ", sessionPerWeek="
				+ sessionPerWeek + "]";
	}
	

}
