package com.capgemini.universityadmission.exception;

public class ViewAllProgramException extends RuntimeException {
	public ViewAllProgramException() {
		System.out.println("something went wrong");
	}

}
