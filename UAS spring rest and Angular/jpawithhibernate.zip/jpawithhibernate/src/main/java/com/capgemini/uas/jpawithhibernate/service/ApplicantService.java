package com.capgemini.uas.jpawithhibernate.service;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;


public interface ApplicantService {

	public List<ProgramsOffered> viewAllProgramsOffered() ;
	public List<ProgramsScheduled> viewAllProgramsScheduleds();
	public List<Application> viewStatus(int applicationId);
	public int apply(Application application);
}
