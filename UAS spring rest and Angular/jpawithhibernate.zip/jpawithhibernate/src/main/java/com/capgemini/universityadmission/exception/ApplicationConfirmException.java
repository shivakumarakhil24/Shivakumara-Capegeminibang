package com.capgemini.universityadmission.exception;

public class ApplicationConfirmException extends RuntimeException {
	
	public ApplicationConfirmException() {
		System.out.println("something went wrong");
	}

}
