package com.capgemini.universityadmission.exception;

public class UserLoginException extends RuntimeException{

	public UserLoginException() {
		System.out.println("Enter valid id and password");
	}
	
	
	
}
