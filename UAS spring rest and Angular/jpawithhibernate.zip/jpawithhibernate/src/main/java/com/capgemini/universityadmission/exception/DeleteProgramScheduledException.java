package com.capgemini.universityadmission.exception;

public class DeleteProgramScheduledException extends RuntimeException{
	public DeleteProgramScheduledException() {
		System.out.println("something went wrong");
	}

}
