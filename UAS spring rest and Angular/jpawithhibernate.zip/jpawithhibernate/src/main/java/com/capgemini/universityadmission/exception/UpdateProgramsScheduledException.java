package com.capgemini.universityadmission.exception;

public class UpdateProgramsScheduledException extends RuntimeException {
	public UpdateProgramsScheduledException() {
		System.out.println("something went wrong");
	}

}
