package com.capgemini.uas.jpawithhibernate.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularVal {
	public String valId(String id) {
		Pattern pat = Pattern.compile("\\w+");
		Matcher mat = pat.matcher(id);
		if(mat.matches()) {
			return id;
		} else {
			return id;
		}
	}
	public String valPass(String pass) {
		Pattern pat = Pattern.compile("\\w+\\d+");
		Matcher mat = pat.matcher(pass);
		if(mat.matches()) {
			return pass;
		} else {
			return pass;
		}
	}
	public String valEmail(String email) {
		Pattern pat = Pattern.compile("\\w+\\@\\w+\\.\\w+");
		Matcher mat = pat.matcher(email);
		if(mat.matches()) {
			return email;
		} else {
			return email;
		}
	}
	public String valRole(String role) {
		Pattern pat = Pattern.compile("\\w+");
		Matcher mat = pat.matcher(role);
		if(mat.matches()) {
			return role;
		} else {
			return role;
		}
	}public String valDate(String date) {
		Pattern pat = Pattern.compile("\\d{4}\\d{2}\\d{2}");
		Matcher mat = pat.matcher(date);
		if(mat.matches()) {
			return date;
		} else {
			return date;
		}
	}

}
