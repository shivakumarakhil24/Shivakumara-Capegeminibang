package com.capgemini.universityadmission.exception;

public class ApplicationRejectException extends RuntimeException {
	
	public ApplicationRejectException() {
		System.out.println("something went wrong");
	}

}
