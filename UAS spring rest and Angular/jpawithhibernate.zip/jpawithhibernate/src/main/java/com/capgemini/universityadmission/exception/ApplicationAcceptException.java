package com.capgemini.universityadmission.exception;

public class ApplicationAcceptException extends RuntimeException{
	public ApplicationAcceptException() {
		System.out.println("something went wrong");
	}

}
