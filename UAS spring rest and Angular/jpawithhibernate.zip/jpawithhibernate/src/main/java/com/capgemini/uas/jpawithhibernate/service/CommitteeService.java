package com.capgemini.uas.jpawithhibernate.service;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;

public interface CommitteeService {
	public boolean login(String loginId, String password,String role);
	public List<Application> viewAllApplications();
	public String editStatus(int applicationId,String status,String doi);

}
