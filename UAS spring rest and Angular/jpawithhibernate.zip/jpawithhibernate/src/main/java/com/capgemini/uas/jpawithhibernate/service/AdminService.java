package com.capgemini.uas.jpawithhibernate.service;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;


public interface AdminService {
	
	public boolean login(String loginId,String password,String role);
	
	public boolean addProgramsOffered(ProgramsOffered program);
	public boolean updateProgramsOffered(ProgramsOffered program);
	public boolean deleteProgramsOffered(String programName);
	
	public boolean addProgramsScheduled(ProgramsScheduled program);
	public boolean updateProgramsScheduled(ProgramsScheduled program);
	public boolean deleteProgramsScheduled(String scheduledProgramId);
	
	public List<Application> viewAllAcceptedApplications();
	public List<Application> viewAllConfirmedApplications();
	public List<Application> viewAllRejectedApplications();
	
	public List<ProgramsScheduled> viewAllScheduledPrograms(String startDate,  String endDate);

}
