package com.capgemini.uas.jpawithhibernate.service;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.dao.CommitteeDao;
import com.capgemini.uas.jpawithhibernate.dao.CommitteeDaoImpl;

public class CommitteeServiceImpl implements CommitteeService {

	CommitteeDao dao = new CommitteeDaoImpl();

	@Override
	public boolean login(String loginId, String password, String role) {
		return dao.login(loginId, password, role);
	}

	@Override
	public List<Application> viewAllApplications() {
		return dao.viewAllApplications();
	}

	@Override
	public String editStatus(int applicationId, String status, String doi) {
		return dao.editStatus(applicationId, status, doi);
	}
}
