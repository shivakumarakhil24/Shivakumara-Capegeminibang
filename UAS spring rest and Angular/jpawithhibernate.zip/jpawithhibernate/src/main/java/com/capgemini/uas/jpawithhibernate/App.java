package com.capgemini.uas.jpawithhibernate;

import java.util.List;
import java.util.Scanner;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;
import com.capgemini.uas.jpawithhibernate.dao.ApplicantDaoImpl;
import com.capgemini.uas.jpawithhibernate.regex.RegularVal;
import com.capgemini.uas.jpawithhibernate.service.AdminService;
import com.capgemini.uas.jpawithhibernate.service.AdminServiceImpl;
import com.capgemini.uas.jpawithhibernate.service.ApplicantService;
import com.capgemini.uas.jpawithhibernate.service.ApplicantServiceImpl;
import com.capgemini.uas.jpawithhibernate.service.CommitteeService;
import com.capgemini.uas.jpawithhibernate.service.CommitteeServiceImpl;

public class App {
	private static Scanner sc = new Scanner(System.in);
	private static AdminService adminService = new AdminServiceImpl();
	private static ApplicantService applicantService = new ApplicantServiceImpl();
	private static CommitteeService committeeService = new CommitteeServiceImpl();
	private static RegularVal validation = new RegularVal();

	public static void main(String[] args) {
		// Repository repository = new Repository();
		System.out.println("Welcome to University Admission");
		// System.out.println("Enter Login detail");

		// adminService.login(sc.next(), sc.next());

		System.out.println("************************************");
		int loginChoice;
		do {
			System.out.println("Select Type of Login");
			System.out.println("1.Users");
			System.out.println("2.Applicant");
			System.out.println("0.Exit");
			System.out.print("Enter your choice: ");
			loginChoice = sc.nextInt();
			System.out.println();

			switch (loginChoice) {
			case 1:
				System.out.println("Enter the user ID : ");
				String id = validation.valId(sc.next());
				while (id == null) {
					System.out.println("Enter Correct User Id");
					id=validation.valId(sc.next());
					}
				System.out.println("Enter the login password");
				String pass = validation.valPass(sc.next());
				while (pass == null) {
					System.out.println("Enter Correct password format");
					pass=validation.valPass(sc.next());
				}
				System.out.println("Enter the role");
				String role = validation.valRole(sc.next());
				while (role == null) {
					System.out.println("Enter Correct Role");
					role=validation.valRole(sc.next());
				}
				boolean adminLoggedIn = adminService.login(id, pass, role);
				boolean macLoggedIn = committeeService.login(id, pass, role);
				if (adminLoggedIn) {
					System.out.println("Welcome to admin");
					adminOperations();
				} else if (macLoggedIn) {
					System.out.println("Welcome to mac");
					macOperations();
				} else {
					System.out.println("Enter the proper credentials");
				}

				break;
			case 2:
				System.out.println("welcome to aspirant");
				applicantOperations();

			} // end of while

		} while (loginChoice != 0);
	}

	private static void adminOperations() {
		int selectChoice;
		do {
			System.out.println("1) addProgramsOffered");
			System.out.println("2) updateProgramsOffered");
			System.out.println("3) deleteProgramsOffered");
			System.out.println("4) addProgramsScheduled");
			System.out.println("5) updatePramsScheduled");
			System.out.println("6) deleteProgramsScheduled");
			System.out.println("7) viewAllConfirmedApplications");
			System.out.println("8) viewAllRejectedApplications");
			System.out.println("9) viewAllAcceptedApplications");
			System.out.println("0) Go Back");
			System.out.println("Enter the choice");
			System.out.println();
			selectChoice = sc.nextInt();
			switch (selectChoice) {
			case 1:
				// addProgramsOffered
				ProgramsOffered addProgramOffered = new ProgramsOffered();
				System.out.println("Enter programe name ");
				addProgramOffered.setProgramName(sc.next());
				System.out.println("Enter the programme description");
				addProgramOffered.setDescription(sc.next());
                System.out.println("Enter the applicant eligibility");
				addProgramOffered.setApplicantEligibility(sc.nextDouble());
				System.out.println("Enter the duartion");
				addProgramOffered.setDuration(sc.next());
				System.out.println("Enter the DegreeCertificateOffered");
				addProgramOffered.setDegreeCertificateOffered(sc.next());
				boolean addProgram = adminService.addProgramsOffered(addProgramOffered);
				if (addProgram) {
					System.out.println("Programme added successfully");
				} else {
					System.out.println("Programme is not added succesfully");
				}
				break;
			case 2:
				// updateProgramsOffered
				ProgramsOffered updateProgram = new ProgramsOffered();
				/*
				 * System.out.println("enter collegeID  to update");
				 * updateProgram.setCollegeID(sc.nextInt());
				 */
				System.out.println("Enter programe name ");
				updateProgram.setProgramName(sc.next());
				System.out.println("Enter the  programme description");
				updateProgram.setDescription(sc.next());
				System.out.println("Enter the applicant eligibility");
				updateProgram.setApplicantEligibility(sc.nextDouble());
				System.out.println("Enter the duartion");
				updateProgram.setDuration(sc.next());
				System.out.println("Enter the DegreeCertificateOffered");
				updateProgram.setDegreeCertificateOffered(sc.next());
				boolean updatePgm = adminService.updateProgramsOffered(updateProgram);
				if (updatePgm) {
					System.out.println("Programme update successfully");
				} else {
					System.out.println("Updation failed");
				}
				break;
			case 3:
				System.out.println("Enter the Programme Name to delete ");
				String delProgram = sc.next();
				boolean deletedPgm = adminService.deleteProgramsOffered(delProgram);
				if (deletedPgm) {
					System.out.println("Programme deleted successfully");
				} else {
					System.out.println("Deleted failed");
				}
				break;
			case 4:
				// addProgramsScheduled
				ProgramsScheduled programsScheduled = new ProgramsScheduled();
				System.out.println("Enter the scheduledProgramId");
				programsScheduled.setScheduledProgramId(sc.next());
				System.out.println("Enter the programme Name");
				programsScheduled.setProgramName(sc.next());
				System.out.println("Enter the location");
				programsScheduled.setLocation(sc.next());
				System.out.println("Enter the start date ");
				programsScheduled.setStartDate(sc.next());
				System.out.println("Enter the End date");
				programsScheduled.setEndDate(sc.next());
				System.out.println("Enter the session per week");
				programsScheduled.setSessionPerWeek(sc.next());
				boolean addScheduled = adminService.addProgramsScheduled(programsScheduled);
				if (addScheduled) {
					System.out.println("Programme scheduled successfully ");
				} else {
					System.out.println("failed");
				}
				break;
			case 5:
				// Update program scheduled
				ProgramsScheduled updateProgramScheduled = new ProgramsScheduled();
				System.out.println("Enter the programme Name");
				updateProgramScheduled.setProgramName(sc.next());
				System.out.println("Enter the scheduledProgramId");
				updateProgramScheduled.setScheduledProgramId(sc.next());
				System.out.println("Enter the location");
				updateProgramScheduled.setLocation(sc.next());
				System.out.println("Enter the start date ");
				updateProgramScheduled.setStartDate(sc.next());
				System.out.println("Enter the End date");
				updateProgramScheduled.setEndDate(sc.next());
				System.out.println("Enter the session per week");
				updateProgramScheduled.setSessionPerWeek(sc.next());
				boolean updateScheduled = adminService.updateProgramsScheduled(updateProgramScheduled);
				if (updateScheduled) {
					System.out.println("Programme  scheduled  updated successfully ");
				} else {
					System.out.println("failed");
				}
				break;
			case 6:
				System.out.println("Enter the scheduled programID to delete ");
				String delete = sc.next();
				boolean deleteScheduled = adminService.deleteProgramsScheduled(delete);
				if (deleteScheduled) {
					System.out.println("programe schedule deleted");
				} else {
					System.out.println("failed to deleted");
				}
				break;

			case 7:
				// viewAllConfirmedApplications
				List<Application> confirmedApplications = adminService.viewAllConfirmedApplications();
				for (Application application : confirmedApplications) {
					System.out.println(application);
				}
				break;
			case 8:
				// viewAllRejectedApplications
				List<Application> rejectedApplications = adminService.viewAllRejectedApplications();
				for (Application application : rejectedApplications) {
					System.out.println(application);
				}
				break;
			case 9:
				// view all accepted application
				List<Application> acceptedApp = adminService.viewAllAcceptedApplications();
				for (Application application : acceptedApp) {
					System.out.println(application);
				}
			default:
				break;
			}
		} while (selectChoice != 0);
	}

	private static void macOperations() {
		int selectChoice;
		CommitteeService service = new CommitteeServiceImpl();
		do {
			System.out.println("1) view applications ");
			System.out.println("2) Update Status");
			System.out.println("0) Exit");
			System.out.println("Enter the choice");
			System.out.println();
			selectChoice = sc.nextInt();
			switch (selectChoice) {
			case 1:
				System.out.println("Available application lists :");

				List<Application> applications = service.viewAllApplications();
				for (Application application : applications) {
					System.out.println(application);
				}
				break;

			case 2:
				System.out.println("Enter application Id needed to be edited");
				int appId = sc.nextInt();
				System.out.println("Set the status for the particular student application ID");
				String stat = sc.next();
				System.out.println("Enter the date of interview ");
				String dateOfInterview = sc.next();

				String status = committeeService.editStatus(appId, stat, dateOfInterview);
				if (status != null) {
					System.out.println("Student is" + status + " interview date is " + dateOfInterview);
				} else {
					System.out.println("Application might not exist");
				}
				break;
			default:
				break;
			}
		} while (selectChoice != 0);
	}

	private static void applicantOperations() {
		int choice;
		ApplicantDaoImpl appManager = new ApplicantDaoImpl();
		do {
			System.out.println("1) Program offered");
			System.out.println("2) Program scheduled");
			System.out.println("3) Apply application");
			System.out.println("4) To view the application status");
			System.out.println("0) Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Program offered");
				List<ProgramsOffered> programs = applicantService.viewAllProgramsOffered();
				if (!programs.isEmpty()) {
					for (ProgramsOffered offered : programs) {
						System.out.println(offered);
					}
				} else {
					System.out.println("No programme offered");
				}
				break;
			case 2:
				System.out.println("Program scheduled");
				List<ProgramsScheduled> programsScheduleds = applicantService.viewAllProgramsScheduleds();
				if (!programsScheduleds.isEmpty()) {
					for (ProgramsScheduled scheduled : programsScheduleds) {
						System.out.println(scheduled);
					}
				} else {
					System.out.println("No programme scheduled");
				}
				break;
			case 3:

				Application application = new Application();
				System.out.println("Enter the applicant name ");
				application.setFullName(sc.next());
				System.out.println("Enter the date of birth ");
				application.setDateOfBirth(sc.next());
				System.out.println("Enter the highest qualification ");
				application.setHighestQualification(sc.next());
				System.out.println("Enter the marks obtained ");
				application.setMarksObtained(sc.nextInt());
				System.out.println("Enter the email Id");
				application.setEmailId(sc.next());
				System.out.println("Enter the goals ");
				application.setGoals(sc.next());
				System.out.println("Enter Program Scheduled ID");
				application.setScheduledProgramId(sc.next());
				int appID = appManager.apply(application);
				System.out.println(
						"You Application Id is : " + appID + ".\n Please keep it with you for future refrence.");
				break;
			case 4:
				System.out.println("Enter the application id to view application status");
				int applnId = sc.nextInt();
				List<Application> viewed = applicantService.viewStatus(applnId);
				System.out.println(viewed);

				break;

			default:
				break;
			}
		} while (choice != 0);

	}
}
