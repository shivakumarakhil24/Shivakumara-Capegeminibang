package com.capgemini.universityadmission.exception;

public class ViewAllAcceptedApplicationException extends RuntimeException {
public ViewAllAcceptedApplicationException() {
	System.out.println("something went wrong");
}
}
