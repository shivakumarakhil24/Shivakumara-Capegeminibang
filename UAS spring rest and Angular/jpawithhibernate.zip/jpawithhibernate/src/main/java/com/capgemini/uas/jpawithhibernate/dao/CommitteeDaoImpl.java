package com.capgemini.uas.jpawithhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.Users;

public class CommitteeDaoImpl implements CommitteeDao {
	@Override
	public boolean login(String loginId, String password, String role) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Users user = entityManager.find(Users.class, loginId);
		boolean logged = false;
		if (user.getLoginId().equals(loginId) && user.getPassword().equals(password)
				&& user.getRole().equalsIgnoreCase("mac")) {
			logged = true;
		}
		return logged;
	}

	@Override
	public List<Application> viewAllApplications() {
		EntityManager entityManager = null;
		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			List<Application> application = null;
			String jpql = "from Application";
			TypedQuery<Application> query = entityManager.createQuery(jpql, Application.class);
			List<Application> list = query.getResultList();
			if (!list.isEmpty()) {
				return list;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
		return null;
	}

	@Override
	public String editStatus(int applicationId, String status, String doi) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();

		String jpql = "Update Application Set status=:status , dateOfInterview=:date_of_interview  where applicationId=:application_id";
		try {
			transaction.begin();
			Query query = entityManager.createQuery(jpql);
			query.setParameter("status", status);
			query.setParameter("date_of_interview", doi);
			query.setParameter("application_id", applicationId);

			int count = query.executeUpdate();

			transaction.commit();
			entityManager.close();
			if (count > 0) {
				return status;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
