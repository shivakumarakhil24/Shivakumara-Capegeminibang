package com.capgemini.universityadmission.exception;

public class ViewAllProgramScheduledException extends RuntimeException{
	public ViewAllProgramScheduledException() {
		System.out.println("something went wrong");
	}

}
