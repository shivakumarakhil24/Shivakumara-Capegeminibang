package com.capgemini.universityadmission.exception;

public class ApplyApplicationException extends RuntimeException {
	public ApplyApplicationException() {
		System.out.println("something went wrong");
	}

}
