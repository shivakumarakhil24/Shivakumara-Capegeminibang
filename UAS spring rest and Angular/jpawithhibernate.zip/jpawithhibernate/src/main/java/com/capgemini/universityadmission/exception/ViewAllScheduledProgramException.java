package com.capgemini.universityadmission.exception;

public class ViewAllScheduledProgramException extends RuntimeException{
	public ViewAllScheduledProgramException() {
		System.out.println("something went wrong");
	}

}
