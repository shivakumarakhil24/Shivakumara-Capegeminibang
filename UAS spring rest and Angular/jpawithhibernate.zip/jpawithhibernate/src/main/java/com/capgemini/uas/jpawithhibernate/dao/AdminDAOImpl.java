package com.capgemini.uas.jpawithhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;
import com.capgemini.uas.jpawithhibernate.beans.Users;

public class AdminDAOImpl implements AdminDao {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
	EntityManager entityManager = null;
	EntityTransaction tran = null;

	@Override
	public boolean login(String loginId, String password, String role) {
		entityManager = entityManagerFactory.createEntityManager();
		Users user = entityManager.find(Users.class, loginId);
		System.out.println(user.getClass());
		boolean logged = false;
		/*
		 * System.out.println(loginId); System.out.println(password);
		 */
		System.out.println(user.getLoginId());
		System.out.println(user.getPassword());
		System.out.println("user role" + user.getRole());

		if (user.getLoginId().equals(loginId) && user.getPassword().equals(password)
				&& user.getRole().equalsIgnoreCase("admin")) {
			logged = true;
		}
		return logged;
	}

	@Override
	public boolean addProgramsOffered(ProgramsOffered program) {
		boolean isAdded = false;
		try {
		entityManager = entityManagerFactory.createEntityManager();	
		tran = entityManager.getTransaction();
		tran.begin();
		entityManager.persist(program);	
			tran.commit();
			isAdded = true;
		} catch (Exception e) {
			tran.rollback();
			e.printStackTrace();
		}
		entityManager.close();
		return isAdded;
	}

	@Override
	public boolean updateProgramsOffered(ProgramsOffered program) {
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			tran = entityManager.getTransaction();

			ProgramsOffered updatedProgram = entityManager.find(ProgramsOffered.class, program.getProgramName());
			updatedProgram.setDegreeCertificateOffered(program.getDegreeCertificateOffered());
			updatedProgram.setApplicantEligibility(program.getApplicantEligibility());
			updatedProgram.setDescription(program.getDescription());
			updatedProgram.setDuration(program.getDuration());
			tran.begin();
			entityManager.persist(updatedProgram);
			tran.commit();

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			entityManager.close();
		}
	}

	@Override
	public boolean deleteProgramsOffered(String programName) {
		boolean isDel = false;
		try {
			entityManager = entityManagerFactory.createEntityManager();
			tran = entityManager.getTransaction();
			tran.begin();
			ProgramsOffered programsOffered = entityManager.find(ProgramsOffered.class, programName);
			entityManager.remove(programsOffered);
			tran.commit();
			isDel = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
		return isDel;
	}

	@Override
	public boolean addProgramsScheduled(ProgramsScheduled programs) {
		boolean isAdded = false;
		try {
		entityManager = entityManagerFactory.createEntityManager();	
		tran = entityManager.getTransaction();
		tran.begin();
		entityManager.persist(programs);	
			tran.commit();
			isAdded = true;
		} catch (Exception e) {
			tran.rollback();
			e.printStackTrace();
		}
		entityManager.close();
		return isAdded;
	}

	@Override

	public boolean updateProgramsScheduled(ProgramsScheduled program) {
			try {
				EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
				EntityManager entityManager = entityManagerFactory.createEntityManager();
				EntityTransaction transaction = entityManager.getTransaction();
				
				ProgramsScheduled updatedProgram =entityManager.find(ProgramsScheduled.class, program.getScheduledProgramId());
				updatedProgram.setLocation(program.getLocation());
				updatedProgram.setProgramName(program.getProgramName());
				updatedProgram.setStartDate(program.getStartDate());
				updatedProgram.setEndDate(program.getEndDate());
				updatedProgram.setSessionPerWeek(program.getSessionPerWeek());
				transaction.begin();
				entityManager.persist(updatedProgram);
				transaction.commit();
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}finally {
				entityManager.close();
			}
	}
	@Override
	public boolean deleteProgramsScheduled(String scheduledProgramId) {
		boolean isDel = false;
		try {
			System.out.println(scheduledProgramId);
			entityManager = entityManagerFactory.createEntityManager();
			tran = entityManager.getTransaction();
			tran.begin();
			ProgramsScheduled programsScheduled = entityManager.find(ProgramsScheduled.class,scheduledProgramId);
			System.out.println(programsScheduled.getProgramName());
			entityManager.remove(programsScheduled);
			tran.commit();
			isDel = true;
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		entityManager.close();
		return isDel;
	}

	@Override
	public List<Application> viewAllAcceptedApplications() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<Application> application = null;
		String jpql = "from Application where status=:acc";	
		Query query = entityManager.createQuery(jpql);
		query.setParameter("acc", "accepted");
		application = query.getResultList();
		entityManager.close();
		return application;
	}

	@Override
	public List<Application> viewAllConfirmedApplications() {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<Application> application = null;
		String jpql = "from Application where status=:conf";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("conf", "confirm");
		application = query.getResultList();
		entityManager.close();
		return application;
	}

	@Override
	public List<Application> viewAllRejectedApplications() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<Application> application = null;
		String jpql = "from Application where status=:rej";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("rej", "rejected");
		application = query.getResultList();
		entityManager.close();
		return application;
	}

	@Override
	public List<ProgramsScheduled> viewAllScheduledPrograms(String startDate, String endDate) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from ProgramsScheduled";
		Query query = entityManager.createQuery(jpql);
		List<ProgramsScheduled> programScheduled = query.getResultList();
		entityManager.close();
		return programScheduled;
	}

}
