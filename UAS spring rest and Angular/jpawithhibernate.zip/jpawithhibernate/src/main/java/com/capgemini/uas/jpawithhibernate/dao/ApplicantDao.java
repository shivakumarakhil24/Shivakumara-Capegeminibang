package com.capgemini.uas.jpawithhibernate.dao;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;

public interface ApplicantDao {
	public List<ProgramsOffered> viewAllProgramsOffered();
	public List<ProgramsScheduled> viewAllSchedulProgramsScheduleds();
	public int apply(Application application);
	public List<Application> viewStatus(int applicationId);
}
