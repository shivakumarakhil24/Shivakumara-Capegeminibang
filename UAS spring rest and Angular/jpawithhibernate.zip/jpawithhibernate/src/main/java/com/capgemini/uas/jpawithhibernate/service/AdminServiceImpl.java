package com.capgemini.uas.jpawithhibernate.service;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;
import com.capgemini.uas.jpawithhibernate.dao.AdminDAOImpl;
import com.capgemini.uas.jpawithhibernate.dao.AdminDao;

public class AdminServiceImpl implements AdminService {

	AdminDao dao = new AdminDAOImpl();

	@Override
	public boolean login(String loginId, String password, String role) {
		return dao.login(loginId, password, role);
	}

	@Override
	public boolean addProgramsOffered(ProgramsOffered program) {
		return dao.addProgramsOffered(program);
	}

	@Override
	public boolean updateProgramsOffered(ProgramsOffered program) {
		return dao.updateProgramsOffered(program);
	}

	@Override
	public boolean deleteProgramsOffered(String programName) {
		return dao.deleteProgramsOffered(programName);
	}

	@Override
	public boolean addProgramsScheduled(ProgramsScheduled program) {
		return dao.addProgramsScheduled(program);
	}

	@Override
	public boolean updateProgramsScheduled(ProgramsScheduled program) {
		return dao.updateProgramsScheduled(program);
	}

	@Override
	public boolean deleteProgramsScheduled(String scheduledProgramId) {
		return dao.deleteProgramsScheduled(scheduledProgramId);
	}

	@Override
	public List<Application> viewAllAcceptedApplications() {
		return dao.viewAllAcceptedApplications();
	}

	@Override
	public List<Application> viewAllConfirmedApplications() {
		return dao.viewAllConfirmedApplications();
	}

	@Override
	public List<Application> viewAllRejectedApplications() {
		return dao.viewAllRejectedApplications();
	}

	@Override
	public List<ProgramsScheduled> viewAllScheduledPrograms(String startDate, String endDate) {
		return dao.viewAllScheduledPrograms(startDate, endDate);
	}
}
