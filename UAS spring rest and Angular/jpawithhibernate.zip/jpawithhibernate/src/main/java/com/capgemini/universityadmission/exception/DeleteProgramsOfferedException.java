package com.capgemini.universityadmission.exception;

public class DeleteProgramsOfferedException extends RuntimeException{
	public DeleteProgramsOfferedException() {
		System.out.println("something went wrong");
	}

}
