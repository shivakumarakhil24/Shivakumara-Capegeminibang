package com.capgemini.uas.jpawithhibernate.service;

import java.util.List;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;
import com.capgemini.uas.jpawithhibernate.dao.ApplicantDao;
import com.capgemini.uas.jpawithhibernate.dao.ApplicantDaoImpl;


public class ApplicantServiceImpl implements ApplicantService {

	ApplicantDao dao = new ApplicantDaoImpl();

	@Override
	public List<ProgramsScheduled> viewAllProgramsScheduleds() {
		return dao.viewAllSchedulProgramsScheduleds();
	}

	

	@Override
	public List<ProgramsOffered> viewAllProgramsOffered() {
		return dao.viewAllProgramsOffered();
	}
	
	@Override
	public int apply(Application application) {
		return dao.apply(application);
	}



	@Override
	public List<Application> viewStatus(int applicationId) {
		return dao.viewStatus(applicationId);
	}	
}
