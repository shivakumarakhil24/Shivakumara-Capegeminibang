package com.capgemini.universityadmission.exception;

public class ViewStatusException extends RuntimeException {
	public ViewStatusException() {
		System.out.println("something went wrong");
	}

}
