package com.capgemini.universityadmission.exception;

public class ViewAllApplicationException extends RuntimeException {
	public ViewAllApplicationException() {
		
	}

}
