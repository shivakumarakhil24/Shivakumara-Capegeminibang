package com.capgemini.universityadmission.exception;

public class AddProgramsOfferedException extends RuntimeException {
	
	public AddProgramsOfferedException(){
		
		System.out.println("something went wrong");
		
	}

}
