package com.capgemini.uas.jpawithhibernate.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.uas.jpawithhibernate.beans.Application;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsOffered;
import com.capgemini.uas.jpawithhibernate.beans.ProgramsScheduled;

public class ApplicantDaoImpl implements ApplicantDao {

	@Override
	public List<ProgramsOffered> viewAllProgramsOffered() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from ProgramsOffered";
		Query query = entityManager.createQuery(jpql);
		List<ProgramsOffered> programOffer = query.getResultList();
		entityManager.close();
		return programOffer;
	}

	@Override
	public List<ProgramsScheduled> viewAllSchedulProgramsScheduleds() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from ProgramsScheduled";
		Query query = entityManager.createQuery(jpql);
		List<ProgramsScheduled> programScheduled = query.getResultList();
		entityManager.close();
		return programScheduled;
	}

	@Override
	public int apply(Application application) {
		EntityManager entityManager = null;
		EntityManagerFactory entityManagerFactory = null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			EntityTransaction tran = entityManager.getTransaction();
			tran.begin();
			entityManager.persist(application);
			tran.commit();
			String jpql = "from Application where emailId=:emailId";
			Query query = entityManager.createQuery(jpql);
			query.setParameter("emailId", application.getEmailId());
			int id = ((Application) query.getSingleResult()).getApplicationId();
			return id;
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
		return 0;
	}

	@Override
	public List<Application> viewStatus(int applicationId) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UniversityPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<Application> applications = null;
		String jpql = "from Application where applicationId=: appId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("appId", applicationId);
		applications = query.getResultList();
		entityManager.close();
		return applications;
	}

}
