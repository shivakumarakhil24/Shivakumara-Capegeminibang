import { SamplePipe } from './sample.pipe';

describe('SamplePipe', () => {
  it('create an instance', () => {
    const pipe = new SamplePipe();
    expect(pipe).toBeTruthy();
  });
});
