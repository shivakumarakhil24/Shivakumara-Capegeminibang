import { Pipe, PipeTransform } from '@angular/core';
import { EmployeeClass } from './employeeClass';


@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(employees: EmployeeClass[], search: string): EmployeeClass[] {
    if (search === undefined) {
      return employees;
    }
    else {
      return employees.filter((value, index, array) => {
        return value.name.toLowerCase().includes(search.toLowerCase());
      });
    };
  }

}
