import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EmployeeClass } from './employeeClass';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  api = 'https://http-shiva-class.firebaseio.com/';
  employees: EmployeeClass[] = [];

  constructor(private http: HttpClient) { }

  postData(data) {
    return this.http.post(`${this.api}employees.json`, data);
  }
  // ...1 here we convert object into array form
  getData() {
    this.http.get(`${this.api}employees.json`).subscribe(data => {
      console.log(data);
      const employeeArray = [];
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          employeeArray.push({ ...data[key], pk: key });
        }
      }
      this.employees = employeeArray;
      console.log(this.employees);
    });
  }
  deleteData(data) {
    return this.http.delete(`${this.api}employees/${data.pk}.json`)
  }

  putData(data) {
    return this.http.put(`${this.api}employees/${data.pk}.json`,data);
  }
}
