import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { EmployeeClass } from '../employeeClass';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  todaysDate = Date.now();
  selectedEmployee: EmployeeClass = {
    empId: null,
    name: null,
    email: null,
    phone: null,
    status: null,
    pk: null
  };


  constructor(private employeeService: EmployeeService) {
    this.employeeService.getData();
  }

  deleteData(employee: EmployeeClass) {
    this.employeeService.deleteData(employee).subscribe(response => {
      console.log(response);
      console.log('deleted one employee');
      //to update again
      this.employeeService.getData();
    }, err => {
      console.log(err)
    });
  }
  selectEmployee(employee: EmployeeClass) {
    this.selectedEmployee = employee;
  }

  submitForm(form: NgForm) {
    this.employeeService.putData(form.value).subscribe(response => {
      console.log(response);
      form.reset();
    }, err => {
      console.log(err);

    });
  }

  ngOnInit() {
  }

}
