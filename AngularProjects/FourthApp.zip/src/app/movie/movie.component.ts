import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {
movie=[];
  constructor(private http:HttpClient) {
    
   }

  ngOnInit() {
  }
  searchMovies(movie) {
    console.log(movie.value);
    this.http.get<any>(`http://www.omdbapi.com/?s=${movie.value}&apikey=9915e1c8`).subscribe(data => {
        this.movie = data.Search;
        console.log(this.movie);
    }, err => {
        console.log(err);
    });
}
}
