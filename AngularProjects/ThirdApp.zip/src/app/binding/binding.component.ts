import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {
  inputData;
  flag=true;
  name='Shivakumar';
  imgURL='https://cdn.pixabay.com/photo/2019/09/23/17/29/elephants-4499210__340.jpg';
  imgURL2='https://cdn.pixabay.com/photo/2015/09/26/13/25/halloween-959049__340.jpg'
  img3='https://cdn.pixabay.com/photo/2017/10/04/18/11/road-2817102__340.jpg'
  constructor() { 
    setInterval(()=> {
      this.flag=!this.flag;
    },1000);
  }
  eventOccured(input) {
    console.log(input.value);
    console.log('key up event occured');
  }

  ngOnInit() {
  }

}
