export class Bike {
    constructor(
        public brand: string,
        public imgUrl: string,
        public model: string,
        public price: number,
        public specs: string

    ) {}
}