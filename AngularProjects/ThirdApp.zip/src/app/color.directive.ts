import { Directive, ElementRef, HostListener, HostBinding } from "@angular/core";

@Directive({
    selector: '[appColor]'
})
 export class ColorDirective {
     constructor(private el: ElementRef) {
         this.el.nativeElement.style.backgroundColor = 'lightpink';
         this.el.nativeElement.style.color = 'black';
         this.el.nativeElement.style.padding = '4px';
         this.el.nativeElement.style.fontSize = '20px';

     }
 
//  ********The above code is to create new custom directive************
// 1.create class
// 2. use decorator @Directive
// 3. give one selector arguments
// 4. declare varible inside constructor using ElementRef service(which create the object of elemnt ref store its objetcs into varaible)
// 5. then inside costructor body write properties variable.nativeElement

@HostBinding('style.fontSize') fontSize;

@HostListener('mouseenter')
mouseenter() {
    console.log('mouse enter');
    this.fontSize = '40px';
    this.el.nativeElement.style.background= 'blue';

}
@HostListener('mouseleave')
mouseleft() {
    console.log('mouse left');
    this.fontSize= '20px';
    this.el.nativeElement.style.background= 'white';

} }