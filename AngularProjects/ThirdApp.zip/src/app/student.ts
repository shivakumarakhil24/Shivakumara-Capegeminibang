export class Student {
    constructor(
        public id: number,
        public name: string,
        public age: Number,
        public degree: string) {

    }


}