import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  products: Product[] = [
    {
      name: 'Mac-book',
      image: 'https://cdn.pixabay.com/photo/2016/11/19/12/34/apple-1839046__340.jpg',
      price: 120000,
      details: 'Very good'
     },{
      name: 'HP',
      image: 'https://cdn.pixabay.com/photo/2016/06/08/10/35/laptop-1443559__340.jpg',
      price: 60000,
      details: 'Good'
     },{
      name: 'Dell',
      image: 'https://cdn.pixabay.com/photo/2017/03/14/20/39/dell-2144351__340.jpg',
      price: 30000,
      details: 'Good'
     },{
      name: 'Acer',
      image: 'https://cdn.pixabay.com/photo/2015/06/19/13/28/tablet-814839__340.jpg',
      price: 20000,
      details: 'Moderate'
     },{
      name: 'Thoshiba',
      image: 'https://cdn.pixabay.com/photo/2018/10/29/12/22/acer-aspire-3-laptop-3781017__340.jpg',
      price: 12000,
      details: 'not well'
     }
  ]
  constructor() { }

  ngOnInit() {
  }

}
