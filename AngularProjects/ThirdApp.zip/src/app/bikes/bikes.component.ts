import { Component, OnInit } from '@angular/core';
import { Bike } from '../bike';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {

  
  bikes: Bike[] = [
    {
      brand: 'Royal',
      imgUrl: 'https://cdn.pixabay.com/photo/2016/04/07/06/53/bmw-1313343__340.jpg',
      model: 'clasic',
      price: 160000,
      specs: 'Very good bike'
    }, {
      brand: 'TVS',
      imgUrl: 'https://cdn.pixabay.com/photo/2015/04/08/23/53/workout-713658__340.jpg',
      model: 'VECTOR',
      price: 60000,
      specs: 'Good bike'
    }, {
      brand: 'HERO HONDA',
      imgUrl: 'https://cdn.pixabay.com/photo/2014/07/05/16/44/biker-384921__340.jpg',
      model: 'Splendor Plus',
      price: 65000,
      specs: 'Ment for Middle class'
    }, {
      brand: 'BaJAJ',
      imgUrl: 'https://cdn.pixabay.com/photo/2014/12/16/03/37/motor-cycle-569865__340.jpg',
      model: 'Pulsur',
      price: 130000,
      specs: 'Very good bike'
    }, {
      brand: 'KTM',
      imgUrl: 'https://image.shutterstock.com/image-photo/closeup-mountain-motocross-race-dirt-260nw-721075027.jpg',
      model: 'Duke',
      price: 160000,
      specs: 'Extradinory  bike'
    }, {
      brand: 'HONDA',
      imgUrl: 'https://cdn.pixabay.com/photo/2017/09/06/17/08/bmw-2722258__340.png',
      model: 'Shine',
      price: 100000,
      specs: 'Pretty good bike'
    } 

  ]
  selectedBike: Bike = this.bikes[0];

  constructor() { }

  selectBike(bike) {
    this.selectedBike=bike;
  }

  ngOnInit() {
  }

}
