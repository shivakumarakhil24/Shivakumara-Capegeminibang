import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-stuctural-directive',
  templateUrl: './stuctural-directive.component.html',
  styleUrls: ['./stuctural-directive.component.css']
})
export class StucturalDirectiveComponent implements OnInit {
  flag = false;
  person= "Dipthesh";
  students: Student[] = [
    {
      id: 123,
      name: 'Abay',
      age: 13,
      degree: 'BE'
    }, {
      id: 23,
      name: 'bay',
      age: 38,
      degree: 'Bcom'
    }, {
      id: 123,
      name: 'Shivu',
      age: 98,
      degree: 'BA'
    }, {
      id: 410,
      name: 'baby',
      age: 24,
      degree: 'BE'
    }, {
      id: 12389,
      name: 'Chinnu',
      age: 18,
      degree: 'BE'
    },
  ];


  constructor() {
    setTimeout(() => {
      this.flag = true;

    }, 2000)
  }

  deletStudent(student: Student) {
    const index = this.students.indexOf(student);
    this.students.splice(index, 1);
  }



  ngOnInit() {
  }

}
