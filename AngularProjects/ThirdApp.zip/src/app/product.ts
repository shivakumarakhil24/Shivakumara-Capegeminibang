export class Product {
    constructor(
        public name: string,
        public image: string,
        public price: number,
        public details: string
    ) {}
}