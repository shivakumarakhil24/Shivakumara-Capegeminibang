import { Component } from '@angular/core';

@Component ({
    selector: 'app-header',
    // template: `<h1>Header component is working<h1>`,
    // styles: [`h1{ background: black; color: lightblue}`]
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent {

}